# eprint 2026/2236 分析与核验记录

> Mounir IDRASSI (AM Crypto, Japan), *A Complete Classification of Whole-Output Linear Structures in FEILIAN-Type Components*, Cryptology ePrint Archive, Paper 2026/2236。投稿 2026-09-27，批准上线 2026-09-28。
> 本地副本：`eprint2236_source/paper_eprint2026-2236.pdf`（全文文本见同名 `_fulltext.txt`）

---

## 0. 结论摘要

**1) 这是一篇组件级结构分析，不是攻击。** 论文 §6 原文自己写死了边界：*"The component results establish no hash attack or bound on the hash's security margin."* 任何人把它读成"FEILIAN 被攻破"都是误读。

**2) 对 FEILIAN 的判定是正面的。** 实际 64-bit SubColumn 的完整整体输出线性结构空间**恰好**是唯一的二维 MSB 族 `S = {(x,y,x,x⊕y)}`（非零元仅 3 个），不存在额外的 mapa 依赖结构；再串联真实 ShiftRow 后，**族中没有任何非零成员能穿过前两个 SubColumn 边界**（式 (10)）。即这一层的对称性刚好是拓扑强制的下界，没有多余。

**3) 我方唯一需要动手的是规范 §4.5.2 的表述。** 那里印出的两个"probability-1 差分"实例**逐字相同**（都是 `(0,M,0,M) ↦ (M,0,M,0)`），读者会以为该结构空间是一维的。论文正是抓住这点：*"both printed SubColumn examples are the same relation … Their input masks span only one dimension."* 应把重复的那一条换成另外两个非零元，并点明空间是二维的。

**4) 论文独立复现了我们此前发现的 AddConstant 行序不一致**（印刷图：tweak 在 row1、常数在 row3；标量 C：常数在 row1、tweak 在 row3），并声明该差异不影响其结论（固定消息/固定 tweak 下二者都是 XOR 平移）。与我们已做的规范修订方向一致。

**5) 三层独立核验全部通过**（详见 §3）：论文钉死的两个源码哈希与本地官方提交包逐位相同；自写 C 探针独立复现 Corollary 5 全部断言；论文自带的代码补充件在本机完整复跑并自报 `reported_values_match = true`、`expected_keys_skipped = []`、`reference_executed = true`。

---

## 1. 论文基本信息

| 项 | 内容 |
|---|---|
| 标题 | A Complete Classification of Whole-Output Linear Structures in FEILIAN-Type Components |
| 作者 | Mounir IDRASSI（AM Crypto, Japan，`mounir@amcrypto.jp`） |
| 日期 | 2026-09-27 收稿 / 2026-09-28 批准 |
| 类别 / 关键词 | Secret-key cryptography；FEILIAN, ARX, linear structures, linear translators, modular addition, linear mixing, hash functions |
| 篇幅 | 16 页 |
| 许可 | CC BY 4.0 |
| 代码补充件 | GitHub `amcrypto-jp/feilian-linear-structures` release `v1.0.0`，`feilian-structures-artifact-20260927-rev08.zip`，SHA-256 `5afc9572a724a3c8cd46555bb96f7baa2ea06bd79ddfae5311f9a364aabcb593` |
| 分析对象 | FEILIAN Round 1 官方包（规范日期 2026-06-30），`Specification.pdf` + `Reference_Implementation/FEILIAN1024/CryptHash_AlgorithmInstance.c` |
| AI 使用声明 | 论文 §7 声明使用 OpenAI Codex、GPT-6 Astra、Moonshot kimi-k3 辅助 |

---

## 2. 它具体证了什么

### 2.1 拓扑与参数

四字 ARX 拓扑（论文式 (1)），字宽 `w ≥ 2`，`N = 2^w`、`M = 2^(w-1)`、`H = {0, M}`：

```
p = a + b,           u = R_r(d ⊕ p),
v = c + d + L_0(u),  q = R_s(b ⊕ v),
F(a,b,c,d) = (p + L_1(q), q, v, u)
```

FEILIAN 用 `w = 64, r = 8, s = 63`，`Σ_0(z) = z ⊕ ROR5(z) ⊕ ROR48(z)`，`Σ_1(z) = z ⊕ ROR11(z) ⊕ ROR40(z)`。这与官方 C 的 `sbox_column`（第 178–186 行）逐行对应。

### 2.2 主要定理

| 结果 | 内容 |
|---|---|
| Lemma 1 | 受限第三加数恒等式的充要条件，分 (+) / (−) 两支；允许 `L_0` 奇异、含 `w = 2` 例外 |
| **Theorem 2** | `(A,B,C,D) ∈ LD(F)` 的充要分类器：先要求 `A,B ∈ H`，再查 `L_0` 的像、最后查 `L_1` 的取值。每支至多 **32 个候选掩码**，与 `w` 无关 |
| Corollary 3 | 普适族 `S = {(x,y,x,x⊕y) : x,y ∈ H} ⊆ LD(F)` 恒成立；`dim LD(F) = 2 + e₀ + e₁ + 1{S⁻≠∅} ≤ 5`，维数 5 可达 |
| Proposition 4 | 负支（例外陪集）存在的充要条件：`im L_0 ⊆ span{1,M}` 加上对 `h₀,h₁,g₀,g₁` 的两次求交判据 |
| Proposition 6 | `LD(G∘L∘F) ∩ LD(F) = {δ ∈ LD(F) : Lφ_F(δ) ∈ LD(G)}`（`F` 双射、`L` 可逆线性） |
| Proposition 7 | 逐边界常数的秩递推：`K_k = ∩_{j<k-2} ker(D_S T_S^j)`，`dim K_k = d − rank(...)`，至多 `d` 次严格降维 |
| **Theorem 8** | 20,160 个可逆二元四行 mixer 配 ShiftRow 的完整传播 census（Table 1） |

### 2.3 对 FEILIAN 的直接结论（Corollary 5）

`w = 64, r = 8, s = 63`、映射如 (3) 时 **`LD(F) = S`，维数 2**，三个非零元为：

| 输入差分 | 常数输出差分 | 规范中的角色 |
|---|---|---|
| `(M, 0, M, M)` | `(M, 0, 0, 0)` | §4.5.2 未印出 |
| `(0, M, 0, M)` | `(M, 0, M, 0)` | §4.5.2 **印了两次**；§4.5.3 半轮例 |
| `(M, M, M, 0)` | `(0, 0, M, 0)` | §4.5.2 未印出 |

并给出 `LD(A) = S⁴`（维数 8），以及

```
LD(A ∘ R ∘ A) ∩ LD(A) = {0}
```

即：**没有任何非零族成员在两个 SubColumn 边界上都保持常数**。

### 2.4 行混合 census（Theorem 8 / Table 1）

固定四列布局与行移位 `R`，令 `B ∈ GL(4,2)` 逐列作用于四行，层间映射换成 `L_B = B∘R`（`B = I` 即真实 ShiftRow）：

| dim K₁ | dim K₂ | dim K₃ | dim K∞ | mixer 数 |
|---|---|---|---|---|
| 8 | 0 | 0 | 0 | 9,216 |
| 8 | 4 | 0 | 0 | 6,912 |
| 8 | 4 | 2 | 2 | 1,152 |
| 8 | 4 | 4 | 4 | 2,304 |
| 8 | 8 | 8 | 8 | 576 |

合计 20,160；其中 `1152 + 2304 + 576 = 4,032`（恰好 **20%**）永久保留非零族，其余 80% 在第三个 SubColumn 层之前被消掉。**真实 FEILIAN（`B = I`）落在第一行 `8→0` 档**，即族在第二个边界即被清除——与式 (10) 自洽，我们已在 §3.2 的 [D] 项数值确认。

论文同时声明：这 20% 描述的是**结构性质，不是 mixer 的安全性排序**。

---

## 3. 三层独立核验

### 3.1 源码钉死哈希（论文 Appendix A vs 本地官方包）

论文在 §A 用 SHA-256 钉死了所分析的文件。与本地官方解包 `%TEMP%\feilian_sub\FEILIAN`（自 `FEILIAN.zip` 2026-09-20 版）逐位比对：

| 文件 | 论文值 | 本地官方包 | 结论 |
|---|---|---|---|
| `Algorithm specifications/Specification.pdf` | `8e3a9a109f3188ab97cbd0156c243f80a6453051cf98006dfef11d66bdeb5fa8` | 同 | ✅ 逐位相同 |
| `.../Reference_Implementation/FEILIAN1024/CryptHash_AlgorithmInstance.c` | `421ee5370e0c5ed33618f371b4ea5a3b14a55f7bc71f0237bf40274e4229f02e` | 同 | ✅ 逐位相同 |

**含义**：论文分析的正是官方提交包原件，不是某个改过的副本；同时也说明它**没有**看到我们工作区里已按评审意见修过的版本。工作区当前（已修）取值：

| 工作区文件 | SHA-256 |
|---|---|
| `Reference_Implementation/FEILIAN1024/CryptHash_AlgorithmInstance.c` | `cf4ad85a74ce38abf652f84d79fd9670606f407c58b3405ef1871a78653819b2` |
| `Reference_Implementation/FEILIAN1024/CryptHash_AlgorithmInstance.h` | `8ab3825c96f001bd5dcbb8899e3a738b6603196f380f1bfcffed0a825b0eeec3` |
| `Reference_Implementation/FEILIAN512/CryptHash_AlgorithmInstance.c` | `ad66dd6c58b0bb99e1527a157aa32b375e17c8e8214cfa62872a80a9c3375bac` |
| `Reference_Implementation/FEILIAN768/CryptHash_AlgorithmInstance.c` | `19ab6dd082cb8c16bf41438b9a300f36a8d0fe506915185e6039c6d853e7e19f` |
| `Optimized_Implementation/FEILIAN_SIMD1024/CryptHash_AlgorithmInstance.c` | `5825349291d7319504395e707842e5eb681bd2a5204d96b8d4a74fcdb7bdf3f9` |

### 3.2 自写 C 探针（不依赖论文代码）

`eprint2236_verify/verify_eprint2236.c`——把**未经改动**的官方标量源文件原样 `#include` 进来，直接调用其 `sbox_column` / `sbox_matrix` / `shift_rows`，独立检验 Corollary 5 的 FEILIAN 具体化。`gcc 15.2.0 -O2 -Wall -Wextra` 零警告编译。

| 检查 | 内容 | 结果 |
|---|---|---|
| A | `h₀ = L₀(R₈(M))`、`h₁ = L₁(R₆₃(M))` 均 ∉ H | `h₀ = 0x0084000000000080`（= 2⁵⁵⊕2⁵⁰⊕2⁷）、`h₁ = 0x0020000001000001`（= 1⊕2⁵³⊕2²⁴），与论文印刷值一致，均不在 `{0, 2⁶³}` ✅ |
| B | 3 个非零元的输出差分 | `(M,0,M,M)↦(M,0,0,0)`、`(0,M,0,M)↦(M,0,M,0)`、`(M,M,M,0)↦(0,0,M,0)`，每掩码 50 万个随机基点（含全零、全 1）全部常数且与论文表格逐字相符 ✅ |
| C | `LD(F) = S`：无外部掩码存活 | `{0,M}⁴` 中 12 个 S 外掩码全部被反例击破；另 20 万个单比特/低重量/随机掩码亦全部被反例击破（每掩码 12 个基点） ✅ |
| D | 式 (10)：`LD(A∘R∘A) ∩ LD(A) = {0}` | 255 个非零 S⁴ 成员，先确认全部 ∈ `LD(A)`（常数），再经 `A∘R∘A` 全部失去常数性 → **幸存 0 个** ✅ |

> 说明：A/B 是精确验证；C/D 的"排除"方向用随机基点抽样（每例最多 12–500000 个基点），属极强的证伪检验，不是穷举。穷举意义上的排除由论文的 Theorem 2/3 与代码补充件承担。

### 3.3 论文自带代码补充件的复跑

| 步骤 | 结果 |
|---|---|
| 下载 release `v1.0.0` 资产 | 31,800 字节 |
| SHA-256 | `5afc9572a724a3c8cd46555bb96f7baa2ea06bd79ddfae5311f9a364aabcb593` ✅ 与论文 §A 印刷值完全一致 |
| 首次运行 | 失败：补充件是 Linux 取向（把 `finite.c` 编成 `finite.so` 后 `ctypes.CDLL` 加载），Windows 上 `FileNotFoundError` |
| 最小可移植性补丁 | 仅共享库命名/链接标志，共 3 处：`finite.so→finite.dll`、`reference.so→reference.dll`、Windows 下加 `-Wl,--export-all-symbols -static-libgcc -static`（否则缺 MinGW 运行时依赖）。算法、参数、种子、比对逻辑一行未动；完整 before/after 见 `eprint2236_verify/portability.patch` |
| 复跑（`run.py --full --submission-root <官方包>`） | **`Completed. All paper values match.` / `Original-reference-C comparisons were executed and passed.`** ✅ |
| 元信息 | `reported_values_match = true`、`reported_values_scope = "all"`、`expected_keys_skipped = []`、`reference_executed = true`、`complete = true` |
| 耗时 | 总计 112.9 s（其中 `reproduce.py` 37.8 s、`audit_evidence.py` 65.5 s），与论文 §A 声称的 ~38 s 同量级 |

复跑数值与论文印刷值逐项对照（全部吻合）：

| 量 | 论文印刷值 | 本机复跑 |
|---|---|---|
| 参数设置记录数 | 2,123 | 2,123 |
| C↔Python 真值表一致条数 | 5,312,768 | 5,312,768 |
| 掩码/基点导数比较次数 | 75,956,572 | 75,956,572 |
| 维数分布（2/3/4/5 维） | 32 / 1,284 / 726 / 81 | 32 / 1,284 / 726 / 81 |
| census 五档 mixer 数 | 9216/6912/1152/2304/576 | 9216/6912/1152/2304/576 |
| 永久保留族的 mixer 数 | 4,032（20%） | 1,152+2,304+576 = 4,032 |
| 参考 C 比对：普通列 / 半轮 / 二层 | 261 / 69 / 69 | 261 / 69 / 69 |
| `Σ` 与旋转的线性比对 | 129 | 129 |
| 255 个非零成员的导数证书比对 | 255×2 = 510 | 510 |
| 官方原件校验数 | 2 | `original_files_verified = 2` |
| 所用源码哈希 | `421ee537…9f02e` | `source_sha256 = 421ee5370e0c5ed33618f371b4ea5a3b14a55f7bc71f0237bf40274e4229f02e` |

**含义**：论文的有限实验部分是**可复现的**，且它自己的参考 C 比对是在**哈希校验过的官方原件**上跑的——这条链是闭合的。

---

## 4. 规范侧需要动的两处

### 4.1 §4.5.2 印了同一个差分两次（**建议改**）

规范原文（`FEILIAN_Specification_sec4.5.txt`）：

> There are differentials of probability of 1 for it. For example,
> 〔列向量 `0000…/8000…/0000…/8000…`〕 → 〔列向量 `8000…/0000…/8000…/0000…`〕 **,**
> 〔列向量 `0000…/8000…/0000…/8000…`〕 → 〔列向量 `8000…/0000…/8000…/0000…`〕 **.**

两条**逐字相同**，都是 `(0,M,0,M) ↦ (M,0,M,0)`。论文据此指出规范给出的输入掩码"只张成一维"。

**建议替换**（`M = 0x8000000000000000`，列内顺序与规范一致，即 `(a₁,b₁,a₀,b₀)`）：

```
There are differentials of probability 1 for it. The set of input differences that
propagate through one SubColumn with a constant whole-output difference is exactly the
two-dimensional space {(x, y, x, x ⊕ y) : x, y ∈ {0, 2^63}}, which has three nonzero members:

   (0, M, 0, M) -> (M, 0, M, 0),
   (M, 0, M, M) -> (M, 0, 0, 0),
   (M, M, M, 0) -> (0, 0, M, 0).
```

三条数值已由 §3.2 的 [B] 项在官方 C 上验证。若要更强口径，可补一句"除该空间外 SubColumn 不存在其他整体输出为常数的输入差分"——该命题由 eprint 2026/2236 的 Theorem 2 / Corollary 3 给出证明，是否引用由我方决定。

### 4.2 AddConstant 行序（论文独立复现，我方已改规范）

论文在两处（§2 第 3 页、§A 第 14 页）指出：

> the specification's diagram puts the tweak in row 1 and constants in row 3, while the scalar C uses the opposite placement.

核对官方 C（`round_without_msg`）：

```c
state[1][c] ^= rc[c];              /* round constants -> row 1 */
state[3][c] ^= flag_and_bits[c];   /* version/flag/bits -> row 3 */
```

确为"常数在 row1、tweak 在 row3"，与印刷图相反——与我们此前的发现**完全一致**，方向也与我们已做的规范修订一致。论文同时明确：固定消息、固定 tweak 下两者都是 XOR 平移，**不影响其结论**（其对应关系只针对组件与行移位）。这条可以作为我方修订的外部佐证。

另注：§4.5.3 的半轮（`SR∘SC`）示例本身是**正确**的——列 0 的 `(0,M,0,M)` 经 SC 变 `(M,0,M,0)`，经 SR 后 MSB 从列 0 移到列 2，与论文的 `R(T) = T`（`T` 为 row0/row2 的 MSB 差分）一致；它的问题只在于"只提供了一个列生成元"。

---

## 5. 口径边界（引用时务必守住）

论文自己写明的限制，逐条列出，避免被外部读成攻击：

1. 所有分类量词都跑在**任意内部组件输入**上；不证明从固定 IV 的**可达性**。
2. **不分类迭代置换的端点结构**——真实 FEILIAN 全轮在 `S⁴` 之外的空间、投影（截断摘要）结构、定量差分概率均标注为 "remain open here"。
3. 消息注入只改 row0/row2，其完整字值差分空间与 `S⁴` 交为 `{0}`（要求 `(x,y,x,x⊕y)` 的 row1/row3 为零即迫使 `x=y=0`），因此**首次注入无法直接造出族中非零元**。论文明确不过渡到"其他消息依赖关系不存在"。
4. 端点/边界常数的区别被刻意区分：Proposition 7 处理的是"**每个**边界都常数"这一更强条件，不是只在端点常数。
5. **Appendix C 的 feedforward 碰撞族用的是被故意改动的 mixer**（`B(a,b,c,d) = (a⊕c, c, a⊕b⊕c, a⊕d)`），论文自己声明 *"is not the specified FEILIAN hash or a fixed-IV message-collision attack"*。
6. 20% / 80% 是**结构性质占比**，论文声明不是 mixer 的安全性排序。
7. Table 4 的模旋转归约是实验性归约，"have no asserted security relation to the 64-bit construction"。
8. 有限实验的定位由论文 Table 2 界定：有限检查不证明普适定理，程序一致性本身也不建立规范忠实性。

---

## 6. 建议的下一步

| 优先 | 事项 |
|---|---|
| 高 | 修订规范 §4.5.2：删掉重复实例，改用三个非零元的完整列表（§4.1 文本可直接用） |
| 中 | 若需对外回应本轮评审，可用本文 §2.3 + §2.4 作为"FEILIAN 组件无多余线性结构、且真实 ShiftRow 在两个边界内清除该族"的**外部独立佐证**——这是对我方有利的结论 |
| 中 | 关注该组是否继续放出后续预印本（同一作者/机构已在做组件级系列分析，v1.0.0 之后可能有更新版本） |
| 低 | 若要在本地长期留存复跑能力，可把 `eprint2236_verify/portability.patch` 反馈给作者仓库（其补充件目前只在 Linux 上开箱可跑） |

---

## 附：产物清单

```
eprint2236_analysis.md                       本文件
eprint2236_source/
  paper_eprint2026-2236.pdf                  论文原件
  paper_eprint2026-2236_fulltext.txt         论文全文文本（pypdf 抽取，16 页）
  FEILIAN_Specification_fulltext.txt         官方规范全文文本（68 页）
  FEILIAN_Specification_sec4.5.txt           规范 §4.5 前后文摘录
  extract_paper_text.py / extract_spec_text.py
eprint2236_verify/
  verify_eprint2236.c                        自写 C 探针（原样 include 官方源）
  CryptHash_AlgorithmInstance.c/.h           官方原件副本（哈希即 421ee537…）
  portability.patch                          代码补充件的最小 Windows 移植补丁
  artifact_evidence/                         补充件复跑产出（reproduction.json、五张表、summaries）
```
