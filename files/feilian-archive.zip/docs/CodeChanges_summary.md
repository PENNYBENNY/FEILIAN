# FEILIAN C 实现改动说明

**基线**：官方提交包 `FEILIAN.zip`（2026-09-20）中的 `Implementations/`
**目标**：`260928/Implementations/`
**改动范围**：12 个文件 —— 6 个 `CryptHash_AlgorithmInstance.c` + 6 个同名 `.h`
**每个文件**：`+70 / −20` 行，5 个 hunk（`.h` 为 `+7 / −2`，1 个 hunk）

基线取自提交包（而非工作区快照），因此下面的 diff 是**可复核的客观差异**，不是回忆。

```bash
# 复核命令（<SUB> = 提交包解包目录）
diff -rq <SUB>/Implementations 260928/Implementations
```

递归比对结果：**只有这 12 个文件不同**。`Additional_Implementation/`（4 个 SystemVerilog 核）、
`KAT_CryptHash.c`、`drng.c`、`drng.h`、`README.txt` 全部逐字节相同 —— 与"只改 C 侧"的要求一致。

---

## 1. 四个 hunk（6 个 `.c` 逐字节同源）

6 个 `.c` 的增删行集合做哈希后**只有一个指纹**（`a30edd40…`）。
归一化 diff 出现 3 个指纹，差异全部来自**上下文行**（SIMD 版有 `ALIGN32` 限定符、HASH_BYTES 宏不同），改动本身完全一致。

### H1 — 新增头文件（1 行）

```diff
 #include "CryptHash_AlgorithmInstance.h"
+#include <limits.h>
 #include <stdint.h>
```

供 H4 的 `SIZE_MAX` / `ULLONG_MAX` 使用。

### H2 — `pad_message()` 重写（hash-10-4 + hash-10-5）

原实现两个问题：整字节 `memcpy` 不过滤末字节的无效低位；`msg_bits + 7`、
`msg_bytes + pad_bytes` 两处加法可回绕。

```c
/* 改动前 */
if (msg_bits == 0) {                                  /* 空消息单独分支 */
    *padded_len = BLOCK_BYTES;
    *padded = (uint8_t *)calloc(BLOCK_BYTES, 1);
    if (*padded == NULL) return 0;
    return 1;
}
size_t msg_bytes = (msg_bits + 7) / 8;                /* 可回绕 */
size_t rem = msg_bits % BLOCK_BITS;
size_t pad_bits = (rem == 0) ? 0 : (BLOCK_BITS - rem);
*padded_len = msg_bytes + (pad_bits + 7) / 8;         /* 可回绕 */
*padded = (uint8_t *)calloc(*padded_len, 1);
if (*padded == NULL) return 0;
memcpy(*padded, msg, msg_bytes);                      /* 末字节无效位未清 */
return *padded_len / BLOCK_BYTES;
```

```c
/* 改动后 */
*padded = NULL;                        /* 失败时保证输出指针可判别 */
*padded_len = 0;

if (msg_bits > SIZE_MAX - 7)           /* NEW: (msg_bits + 7) 回绕保护 */
    return 0;
msg_bytes = (msg_bits + 7) / 8;

rem = msg_bits % BLOCK_BITS;
pad_bits = (rem == 0) ? 0 : (BLOCK_BITS - rem);
pad_bytes = (pad_bits + 7) / 8;
if (msg_bytes > SIZE_MAX - pad_bytes)  /* NEW: 填充长度回绕保护 */
    return 0;

len = msg_bytes + pad_bytes;
if (len == 0)
    len = BLOCK_BYTES;                 /* 空消息仍走一个全填充块（保持原语义） */

*padded = (uint8_t *)calloc(len, 1);
if (*padded == NULL)
    return 0;

if (msg_bytes != 0) {
    memcpy(*padded, msg, msg_bytes);
    if (msg_bits % 8 != 0) {           /* NEW: bit 级长度 */
        (*padded)[msg_bytes - 1] &= (uint8_t)(0xFFU << (8 - (msg_bits % 8)));
    }
}

*padded_len = len;
return len / BLOCK_BYTES;
```

**要点**

- 变量声明全部移到函数开头（C99 之前风格也更安全），空消息分支被合并进统一路径，行为不变。
- mask 值 `0xFFU << (8 - msg_bits % 8)` 与 KAT 生成器 `drng.c:305` 的 `HIGH_N_BIT_MASK` 取值完全相同 —— 这是"对 KAT 零影响"的直接原因。
- 返回 `0` 仍表示失败，但**失败语义被扩展**：现在也涵盖长度回绕。文档注释写明了"调用方必须把 0 当错误"。

### H3 — `feilian_hash_internal()` 返回值上抛（hash-10-1）

```diff
-static void feilian_hash_internal(const uint8_t *msg, size_t msg_bits,
-                                  uint8_t hash_out[HASH_BYTES])
+/* On success returns 0 and fills hash_out; returns -1 when the padded message
+   cannot be built (allocation failure or length overflow).  hash_out is left
+   untouched in that case, so the caller must not use it. */
+static int feilian_hash_internal(const uint8_t *msg, size_t msg_bits,
+                                 uint8_t hash_out[HASH_BYTES])
 {
     uint8_t *padded = NULL;
     size_t padded_len = 0;
     size_t num_blocks = pad_message(msg, msg_bits, &padded, &padded_len);
-    if (padded == NULL) {
-        memset(hash_out, 0, HASH_BYTES);      /* 失败却产出"全零摘要"并当成功返回 */
-        return;
-    }
+    if (num_blocks == 0)
+        return -1;
```

函数尾部：

```diff
     free(padded);
     store_state(hash_out, h_curr);
+    return 0;
 }
```

判据从 `padded == NULL` 改成 `num_blocks == 0` —— 后者同时覆盖分配失败与长度回绕，
且不依赖 `calloc(0)` 的实现定义行为（原判据在空消息路径上与 `*padded_len` 耦合，易漏）。

### H4 — `CryptHash()` 入参与错误传播（hash-10-1 + hash-10-5）

```diff
     if (digest == NULL)
         return -1;

+    /* Reject bit lengths that this platform cannot represent as a size_t: the
+       padding arithmetic below operates on size_t. */
+#if defined(SIZE_MAX) && defined(ULLONG_MAX) && (SIZE_MAX < ULLONG_MAX)
+    if (msg_len_bits > (unsigned long long)SIZE_MAX)
+        return -1;
+#endif
+
+    size_t msg_bits = (size_t)msg_len_bits;
+
     uint8_t full_digest[HASH_BYTES];
-    feilian_hash_internal(msg, (size_t)msg_len_bits, full_digest);
+    if (feilian_hash_internal(msg, msg_bits, full_digest) != 0) {
+        /* Padding failed (allocation failure or arithmetic overflow).  Report
+           the error instead of returning an all-zero digest as success. */
+        return -1;
+    }

     size_t out_bytes = (size_t)((digest_len_bits + 7) / 8);
     memcpy(digest, full_digest, out_bytes);
```

`#if` 使 32 位平台上 `msg_len_bits` 可超 `size_t` 的输入被显式拒绝；64 位平台该分支被预处理掉，零开销。
失败时**不写 `digest`**，调用方不会拿到"合法格式的假摘要"。

### H5 — 头文件接口注释（6 个 `.h` 完全同一份改动）

```diff
-    /// @param[in] msg_len_bits The total BITS of message
+    /// @param[in] msg_len_bits The total BITS of message. The message is a bit
+    ///        string: when the length is not a multiple of 8, the message ends
+    ///        inside the last byte and the remaining low-order bits of that
+    ///        byte lie outside the message and shall not affect the digest.
     /// @param[out] digest The base address of digest
-    /// @return 0 for success, others for error
+    /// @return 0 for success. A non-zero value means the arguments were invalid
+    ///         or the padded message could not be built; no digest is produced
+    ///         in that case and the caller must not use the output buffer.
```

把 H2/H3/H4 确立的契约写进接口：**谁是消息的一部分**（bit 串语义），**失败时不产出摘要**。

---

## 2. 改动落点行号（当前文件）

| 变体 | `#include <limits.h>` | `pad_message` | mask 行 | `feilian_hash_internal` | `num_blocks == 0` | `return 0;` | `msg_len_bits > SIZE_MAX` | 调用点上抛 |
|---|---|---|---|---|---|---|---|---|
| Reference/FEILIAN512 | 13 | 86 | 121 | 336 | 342 | 375 | 395 | 402 |
| Reference/FEILIAN768 | 13 | 86 | 121 | 336 | 342 | 375 | 395 | 402 |
| Reference/FEILIAN1024 | 13 | 86 | 121 | 342 | 348 | 383 | 403 | 410 |
| Optimized/FEILIAN_SIMD512 | 13 | 194 | 229 | 386 | 392 | 435 | 455 | 462 |
| Optimized/FEILIAN_SIMD768 | 13 | 194 | 229 | 386 | 392 | 435 | 455 | 462 |
| Optimized/FEILIAN_SIMD1024 | 13 | 199 | 234 | 398 | 404 | 448 | 468 | 475 |

头文件：`@param[in] msg_len_bits` 起于第 27 行（1024 参考实现为 34 行，其函数注释块更长），`@return` 起于第 32 / 39 行。

---

## 3. 改动后状态复核（本轮新跑）

| 检查 | 结果 |
|---|---|
| 递归目录比对 | 仅 12 个文件不同；RTL / KAT / drng / README 逐字节相同 |
| 6 个 `.c` 增删行指纹 | 单一指纹 `a30edd40…` → 6 处改动逐字节同源 |
| 6 个 `.h` 归一化 diff 指纹 | 单一指纹 `bdff7365…` → 同一份注释改动 |
| 官方构建命令（`KAT_CryptHash.c` + `drng.c`） | 6 个变体 `rc=0` |
| `-Wall -Wextra`（参考实现） | 0 警告 |
| `-Wall -Wextra`（SIMD） | 各 2 个 `unused-const-variable`（`rot16_mask` / `rot24_mask`），**基线同为 2 个**，非本次引入 |

---

## 4. 明确未改动

| 项目 | 原因 |
|---|---|
| 4 个 RTL 核（1SC/2SC/4SC/8SC） | 用户要求不动。遗留：`core.sv` 的 `cf_domain` 用压缩前累加器；1SC/4SC/8SC 计数器字序与 C 相反；接口只有 `valid_bytes`，无法表达 partial byte；1SC/4SC 的 `VERSION`/`DIGEST_BITS` 与 README 标称冲突 |
| `KAT_CryptHash.c` / `drng.c` / `drng.h` | 规范要求 SHALL NOT be modified |
| 末块计数器 `block_bits = msg_bits - i * BLOCK_BITS` | **本来就是正确写法**（真长度口径），无需改动 |
| 规范 Appendix B 数值 | 另一条工作线，产物见 `AppendixB_test_vectors_revised.txt` |

---

## 5. 相关文件

- `CodeChanges_unified.diff` —— 12 个文件的完整 unified diff（路径头已归一化为 `a/`、`b/`）
- `AppendixB_conformance_note.md` —— Appendix B 计数器口径的根因核查
- `AppendixB_revision_diff.md` —— Appendix B 24 处数值变更对照
