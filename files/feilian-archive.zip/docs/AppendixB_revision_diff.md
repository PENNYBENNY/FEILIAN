# Appendix B — regenerated test vectors: what changed

Source of the new numbers: the algorithms as shipped in the NGCC submission
(`FEILIAN.zip`, Reference 512/768/1024), instrumented only to dump the
intermediate states.  Nothing in the algorithm was altered.

For every section the counter `t` is the **true cumulative message length**:
`t = min(1024·(i+1), ‖M‖)`, i.e. the tweak of the final block excludes the padding.

Sections changed: **24**

| variant | example | block | section | words changed | old (as printed) | new (correct) |
|---|---|---|---|---|---|---|
| FEILIAN-768 | abc (24-bit) | 0 | State v after 1 round | 1/16 | `8334de7038cdcb85 …` | `8334de7038cdcb85 …` |
| FEILIAN-768 | abc (24-bit) | 0 | State v after 2 rounds | 15/16 | `7f646b7c248841a2 …` | `73b0fdd43c91cb0b …` |
| FEILIAN-768 | abc (24-bit) | 0 | State v after 5 rounds | 16/16 | `de21c355a1b950be …` | `7d46a116b094ac9a …` |
| FEILIAN-768 | abc (24-bit) | 0 | State v after 10 rounds | 16/16 | `95488e223247f4f4 …` | `ec4e2d1aa17a21ab …` |
| FEILIAN-768 | abc (24-bit) | 0 | State v after 20 rounds | 16/16 | `ff4e91e0df509d63 …` | `2de402756ddb0239 …` |
| FEILIAN-768 | abc (24-bit) | 0 | Hash digest output | 12/12 | `b095f35a68fb71db …` | `ea0a78e8fd68db09 …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | State v after 1 round | 1/16 | `cf338bfaeb153338 …` | `cf338bfaeb153338 …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | State v after 2 rounds | 15/16 | `cd3c340ac9d48ad0 …` | `90ea9df391ece007 …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | State v after 5 rounds | 16/16 | `cbb6981f6b7adb9d …` | `e6a628eddbbd8331 …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | State v after 10 rounds | 16/16 | `f8f694f77fa111ad …` | `d3a4ae62cb27a8e0 …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | State v after 20 rounds | 16/16 | `00c180279655dec2 …` | `eede123c543d419d …` |
| FEILIAN-768 | a×129 (1032-bit) | 1 | Hash digest output | 12/12 | `00562e578ec89807 …` | `5fc94695955a87e9 …` |
| FEILIAN-512 | abc (24-bit) | 0 | State v after 1 round | 1/16 | `8334de7038cdcb85 …` | `8334de7038cdcb85 …` |
| FEILIAN-512 | abc (24-bit) | 0 | State v after 2 rounds | 15/16 | `a0c151a81b29cdf4 …` | `906cc3b032de164b …` |
| FEILIAN-512 | abc (24-bit) | 0 | State v after 5 rounds | 16/16 | `b65d0573f2209ba6 …` | `818ea9fa141660cc …` |
| FEILIAN-512 | abc (24-bit) | 0 | State v after 10 rounds | 16/16 | `ecf3ccf978b80922 …` | `8b26efced5440aed …` |
| FEILIAN-512 | abc (24-bit) | 0 | State v after 20 rounds | 16/16 | `26cb47b9ea6b9765 …` | `e2319ced40837b2f …` |
| FEILIAN-512 | abc (24-bit) | 0 | Hash digest output | 8/8 | `b69fc86f312df402 …` | `fc7320c565f60ec6 …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | State v after 1 round | 1/16 | `1b92ba0b8ed9901e …` | `1b92ba0b8ed9901e …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | State v after 2 rounds | 15/16 | `3997f897738d7264 …` | `ca7d7e7f3bf549bd …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | State v after 5 rounds | 16/16 | `899e8207f6607ea8 …` | `7a9c4a471ead8d5b …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | State v after 10 rounds | 16/16 | `a3a66d718393b190 …` | `c76fc8b46fcecd5e …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | State v after 20 rounds | 16/16 | `b72bcb92da14a15c …` | `36cf6853dfd3c131 …` |
| FEILIAN-512 | a×129 (1032-bit) | 1 | Hash digest output | 8/8 | `cf785e5010f69c0d …` | `a2189955d155788c …` |

Full values, section by section:

**FEILIAN-768, abc (24-bit), block 0, State v after 1 round**

```
old  8334de7038cdcb85 1ed8141136e28928 01f91f2586257b36 e144101a72c1b40d
old  20a41f6053903a10 aba2702e4678c28b b534895121a43005 af9b86363b90286f
old  a4bb3345dc6194ed 2b4763887f4d9534 772e0ec74cef7f04 c04630135814353b
old  be8a831ae6878aaa f39b181cdcf4ed4d a8400088d9b51f91 07b30666c664c54d
new  8334de7038cdcb85 1ed8141136e28928 01f91f2586257b36 e144101a72c1b40d
new  20a41f6053903a10 aba2702e4678c28b b534895121a43005 af9b86363b90286f
new  a4bb3345dc6194ed 2b4763887f4d9534 772e0ec74cef7f04 c04630135814353b
new  be8a831ae6878aaa f39b181cdcf4ed4d a8400088d9b51f91 07b30666c664c155
```

**FEILIAN-768, abc (24-bit), block 0, State v after 2 rounds**

```
old  7f646b7c248841a2 674b63e7d4e87d4d 573884a1d15d84c3 9040ec47c4110a8a
old  731bb68962919054 5ca3d7d06e9dc61d ee491bc88101a4a2 ac5f4eaa995eb3de
old  95df00ebc07d9f10 47999b4cc9d5458e 5da1ac397d69f946 624acac2dc654b62
old  743cc1de831d75fc 588d44021640a229 29b4565194ce68d7 b63e7c4c79c8ea3a
new  73b0fdd43c91cb0b 78d15bbfdcd0d450 6b0141517846e55b 5045ec90dd3872e2
new  439bb6896289b85c 22c5dfd08e1cd797 ac49f66b56c71c11 a5edceaa995ebbf6
new  fb6c04ebb035cfed e699ed9d223619d7 5978ec397d69fd52 7a0acac2dc695f66
new  2beb77f7db553cd5 5c9544021640a229 29b4565194ce68d7 ee6ffc4c79c8f9ea
```

**FEILIAN-768, abc (24-bit), block 0, State v after 5 rounds**

```
old  de21c355a1b950be 553d9add74aaccc2 3ca4167f02eb5e3d 556678a4f0feb511
old  2f3812773723cfa1 b798a47345878735 4daceaddcc0bdc46 05eeaf36b572e75d
old  fcaca424dd81aef0 32ec58b967abdd41 b7532568609be8e4 8bb191cacc71079f
old  fa02830cd06d85b6 b2f7d96592f350b8 a75e56eb86f874ea ba752cadc77f20d6
new  7d46a116b094ac9a dd04709a65a782d5 36f63c4b21cef29d c20398f2bed4ac8e
new  cc7cad46876fd73f 8440479822eedbe7 21021d6f15ae4c40 8fa937cd26cee9ea
new  5fba1b51da621582 c65755bd63ba1ad4 70da8cd50eac766d 7d827beb1e70997c
new  45b78ffc77b9c304 63ac62470117682e 686b5dfb12d43474 70b98008f05ef858
```

**FEILIAN-768, abc (24-bit), block 0, State v after 10 rounds**

```
old  95488e223247f4f4 9d96ca8afb6c12dd f2a692a2d1be6580 e1229f94a3db639d
old  f0778c0f4a120ffc 29b23aac47f83756 96ec3336ff0538f1 9d84e530b42d8b46
old  bc3e8dee12d54c8d b1b8d54eeed6b9b8 29c4feae0af0ac37 ed85390a093c5af9
old  c925a5d7d66086ba 37c5237c654c4360 6370870c6192e9e6 3a7a82fe15e4a39c
new  ec4e2d1aa17a21ab c76d0ca15ea9a6d2 8456d3c516d01393 2fc7b7b014b78d0f
new  6d4688c5744bab30 1f5a0e0c3314601a b0ef9baf6d82fdcb a5034476af1e5b35
new  6ea9579eda7ad77a 681c5591a7db2876 09f79de3e707457d a2ee2cc660b8db6b
new  eda585af389ef7b2 c754f10ed7024d07 b39af34309cddbe7 42de634b24537f93
```

**FEILIAN-768, abc (24-bit), block 0, State v after 20 rounds**

```
old  ff4e91e0df509d63 36ec27ce643c82ff d07c066f6d084190 a1c46500ce3faefc
old  450d87b55f8ef52a ff352036c7870627 5666def8b9c55888 271f8bb73849ae92
old  187bd64f6cda780c 4e49d17e1b6e7f77 b1188e9afa4196f8 26561c44123c76ba
old  bcfa9a224cb720ba 544db3a6dfc420b4 09b08396c075ce7b 89349a50106f86b2
new  2de402756ddb0239 f508d95bd6a129eb 3bfef1db6bb80fd7 5c3a641e3028f542
new  afc09e4f6499d1cd 81debf030cff3f43 70250122e2c89db3 ab7ae15c930d0cfb
new  a6ad110fd6f290ef 264785a4f1670a19 918bb02a4916633c 594a0ad44dfa645d
new  f0fc84604631a0a9 eaa1908c3a32bab9 f8ca5487c084978e efe3b8139c865098
```

**FEILIAN-768, abc (24-bit), block 0, Hash digest output**

```
old  b095f35a68fb71db bbf14c67e0adf525 407097444d3e7574 75c27122989feaa9
old  5de65e6753a62500 4b0a6ef3f9466141 5508b9704ff7ca96 85a70e8d025e9b18
old  1783a3e596036d8a dbcab183d8da789f 4f495b2a41fce59e 2c081a78a9b3b79e
new  ea0a78e8fd68db09 af5ad1d5755311e6 073e2742f9c9f79f cb9966dc869e1454
new  bac2495ca9bfe8ea 2f331638ccd98a3f 6ecdb42b952889b0 ec054a26e934fe94
new  f46b8b5fd6c4bb34 b5bfb869028e76f7 8bbc0c99f1c276be cb1adc2739a5abe1
```

**FEILIAN-768, a×129 (1032-bit), block 1, State v after 1 round**

```
old  cf338bfaeb153338 ea65bd2fe9e4f36f 672887b6172d14dd b0c273fcedfcc11c
old  17591bc9b6e2e6ac 04a66b88d4cb6372 91f15bc5ee402fa9 613a21538376ae9d
old  9f2f4e4b278df2fc 40ae1df1de754d82 5ed2e6a632250ee8 0ab17e093603a9fa
old  c11996a97b9a0bf4 d656bd13d8ec8785 76f9ee871a3d5954 328a64f3b1b85fb5
new  cf338bfaeb153338 ea65bd2fe9e4f36f 672887b6172d14dd b0c273fcedfcc11c
new  17591bc9b6e2e6ac 04a66b88d4cb6372 91f15bc5ee402fa9 613a21538376ae9d
new  9f2f4e4b278df2fc 40ae1df1de754d82 5ed2e6a632250ee8 0ab17e093603a9fa
new  c11996a97b9a0bf4 d656bd13d8ec8785 76f9ee871a3d5954 328a64f3b1b853bd
```

**FEILIAN-768, a×129 (1032-bit), block 1, State v after 2 rounds**

```
old  cd3c340ac9d48ad0 792062fc8c56030a ae8080ce9ca43f9e da8daad72b4c3666
old  b0a5b41f33c13025 bbc89f6b02ad0ae7 e56ad45bdb1028dd 5b836f0cf0a34eb3
old  adfcb957de8b1e26 a9f17669b09ae509 ef0eb650dad244ee ad72ec379ec76358
old  06391cc7540fce82 76ff23bf23420073 58e16f7dc1844cca 573cee67bc9f822d
new  90ea9df391ece007 48b69b64952d6610 92dddc41a30ceac6 9f7db95c3d79ea63
new  6125b41f3339482c f01ed76bd2437e3e 7e95ffb25ecea352 6353ef0cf0a3456b
new  c7979d57b6943c43 640ee39d7275a0ce f366f650dad24102 45b2ec379ebb5f5c
new  3860854f6c07716f 7af723bf23420073 58e16f7dc1844cca ae696e67bc9e662d
```

**FEILIAN-768, a×129 (1032-bit), block 1, State v after 5 rounds**

```
old  cbb6981f6b7adb9d d57c38916f68a236 36b0ee73ba0c85d2 6477253246555914
old  c4685a606a8edfd9 e4fbf75fa18570e6 1d1aeeb4724a0e1f a4c1f9831033b5b4
old  6db6af1202d5224a 58852cdfc1449ad3 5b508f3ef1bf1e77 fa53f7d06ce870fc
old  4f124b4b694b4b20 499da53e4f8e4158 602715a9160a1859 d32f8bf030d6d8ba
new  e6a628eddbbd8331 62a4c898d6f4b487 05d7a8355e17116f 44c4c709f4cbc6a2
new  1678e79f25f419e7 1e7c4e9689c74bd2 3c025e5dda22b127 208b7fa03a103306
new  1714e90fadd7256a 4e7505d96537ef2c bac9ad24a6443d41 47ffa9c5c895d8b6
new  9f42bd67feaf75ec 6c488736a778c494 db5adf61b603d227 6071447d7b2b4deb
```

**FEILIAN-768, a×129 (1032-bit), block 1, State v after 10 rounds**

```
old  f8f694f77fa111ad 55fefa5802e474d1 672e6a1f65eb0df7 3661627f1f5ff549
old  9f0b50541d1f7603 eed1b03f9534e506 dff1d54b2bdc5d6f 8cbe215fc93510c9
old  f7ff25a3850018ce c7d509258dbae269 e069b81805bbfce0 1ddc46c0dc62eb20
old  55f714608506fd03 61613cda9f5dc146 2f420c407ce44e9f 4216a428fff065d8
new  d3a4ae62cb27a8e0 ea908652d9a5f0a5 1fd06460da15cec9 1321eef023744756
new  b8ccedb978a0e270 6f7b1f35ae5f48a0 2bb2bad327462431 77a972ed8d813fc8
new  45c10c174d7b386d a79555b425ace398 941cbe33f6ca7437 1349c7e61ed80a48
new  fbe61166b5d264dd 85cd4acf6a9616eb 4469ab966a966d71 f3aba9d3c6118659
```

**FEILIAN-768, a×129 (1032-bit), block 1, State v after 20 rounds**

```
old  00c180279655dec2 b3e207355516f0bc 93e44bec78ed9022 6cbfb364c4f8e459
old  c37cdcd590c1fc59 2c9be4f36ae283c0 87ddd3e550022d1c cd079b9339cfbc9d
old  77c7f01cbc30cf4e 81b4cb3e259e3a1b 8dcf80ac7f48304e 7b715a0554dbcfad
old  c13590592803b835 b31825790eb787fc a37b9b8509157b56 6b89ce11ef473a40
new  eede123c543d419d 18c90efd902d4543 b0759277c8c4d1cc 5cdb9445713bf6eb
new  35afe80502b142d1 2ca0bb809d1b4a76 93b1e3566dc2ec61 efe0e961c45f3940
new  22155122999dc0c6 4aeb46f582f0b5c2 34297835e3cc387b d8e933f74fd8fbc7
new  0b57e7a9aa1165de 39187252b00817cf 06571b7d9c518532 3d739195a005293e
```

**FEILIAN-768, a×129 (1032-bit), block 1, Hash digest output**

```
old  00562e578ec89807 214f94466f4f2c98 30984811b0a5c424 88e3a2a9ae752709
old  27fe707f683617b5 847bb3b6f40d6b40 9cee8e6ebf535b83 1fada3ee5a40a37e
old  3e203f491651360a a544e53be9f556af 731c989b7d979e19 7e9f2b54c58f4c5e
new  5fc94695955a87e9 defaaf83a7460733 ded961a12b7c5507 3af1611c8f524339
new  af4000edb802c443 32b24a4187525040 e12f4e530c633797 c2283313a832445c
new  b62f926c28f0e45f 7ccb8b9c22780964 46141c07e46f78a0 14ab284f37e6d4fd
```

**FEILIAN-512, abc (24-bit), block 0, State v after 1 round**

```
old  8334de7038cdcb85 1ed8141136e28928 01f91f2586257b36 e144101a72c1b40d
old  20a41f6053903a10 aba2702e4678c28b b534895121a43005 af9b86363b90286f
old  a4bb3345dc6194ed 2b4763887f4d9534 772e0ec74cef7f04 c04630135814353b
old  be8a831ae6878baa f39b181cdcf4ed4d a8400088d9b51f91 07b30666c664c54d
new  8334de7038cdcb85 1ed8141136e28928 01f91f2586257b36 e144101a72c1b40d
new  20a41f6053903a10 aba2702e4678c28b b534895121a43005 af9b86363b90286f
new  a4bb3345dc6194ed 2b4763887f4d9534 772e0ec74cef7f04 c04630135814353b
new  be8a831ae6878baa f39b181cdcf4ed4d a8400088d9b51f91 07b30666c664c155
```

**FEILIAN-512, abc (24-bit), block 0, State v after 2 rounds**

```
old  a0c151a81b29cdf4 aa1b21dddae67f46 06f67eabcf6b268e 4fadecacb7ff4e28
old  710bb68962919e52 4ca3d7d06e9bb81f aa0a1bcb07895c11 9f5f3a36fa127f22
old  9ddf00ebc07ea011 f5b81b4d0aef07d1 442196774ccf9f38 6342cac2dc654c61
old  760cc1de831d3616 195d865c244a101e 28b4565194ce68d7 b63e7c4c79c8ea3a
new  906cc3b032de164b baa11995e2ceba49 7b8b433b7671141b 55d087adde7f26c5
new  418bb6896289c65a d2c5dfd08e1ae990 5688f66bd2201b96 68eeba36fa12771a
new  036c04ebb036d0ee 0bf96d9d603ba412 3ff956774ccf9b24 7b02cac2dc696065
new  15fb77f7db55ffef 1d45865c244a101e 28b4565194ce68d7 ee6ffc4c79c8f9ea
```

**FEILIAN-512, abc (24-bit), block 0, State v after 5 rounds**

```
old  b65d0573f2209ba6 9c52a4d8ed9ebeb1 41a81a52e118ae63 b3471ab2b77dc622
old  03f63f2b13ccf183 3ec26ecdeedc43e7 92eec6993a4f1d48 e7fbe12863b99895
old  e745ea3263b89992 72e41b2e23e20f7e 7cfbadda31207162 76c2e80683046882
old  6a012055487181e4 b2059c3c8c4b4819 8b8ea619fd9e6f45 126122463f325bff
new  818ea9fa141660cc d6adbd05b3c3f00c e02e02f33674d0eb 1bf0837445a06970
new  4a6d4957c6a9ce58 f2019acb6c72ac46 0bd95a90f2a59cd6 3161f067882f8797
new  dbe7d720f89018bc 22f356cd9a15623c 8ac760e9f70c0204 7c4659c0b90f862f
new  7da9c43c84a86bdb f449bb008d56d766 bd6bf22c6229cae3 107382b4e9868cdb
```

**FEILIAN-512, abc (24-bit), block 0, State v after 10 rounds**

```
old  ecf3ccf978b80922 02ac9177d533b7d5 032a73f0758696ed 359ab3da6051e97a
old  76790ad44feb9268 b6ed71f6e6f17e99 410f95e3ffb8d523 0ad1fd3160b83b32
old  e9c904e61ab766b2 a5162afdbbdcc4d4 7787b4db76b89d3b 8c8a8b30c1b8ce74
old  60b81fce5cb6bd42 61ab79dc511b8bd8 6839c81cc6c1a2a5 0b2b46774580f134
new  8b26efced5440aed 89ae95190ebc78b4 c80ce8a2494e6fcf b8147599fa8e9dba
new  6bec1d86f97c46c9 09fa50469f361879 e2d6b325cb8b54d0 da4fffb38f4d6bf7
new  85eeb4bcad0c4ad5 891e7190e94ed6bc 5ccece6dfd25dc3e b8eb98530c666df9
new  2977b07e2048a7d3 340a3e019ce2fa0f aa51410057be5f7d fb6c70c27281e8c0
```

**FEILIAN-512, abc (24-bit), block 0, State v after 20 rounds**

```
old  26cb47b9ea6b9765 7b2e214f3f542eb9 8cd7dfd0e4244355 84d4926a973e5b6e
old  aa92c16124859399 bf706442eda3af03 2aaf6df838ca6578 00b9e5f871ba689b
old  68761e997bc73e88 1dc987c3962787ab 1ec2998b9b0ab10e 30d250c269c3e3d8
old  875e9dab5b93126e cbdf8ecf9bc74b02 1b6c109e0fc04edc ed1460b8fab2ce8c
new  e2319ced40837b2f 0c64f6715b5699e2 c8f2e983308ea280 9cce4641523f0629
new  49a6c5952bc73109 5ba7e84f0206bdf7 d32eaa42c6b90627 4f967b73e54043a2
new  847995d5d5f1b107 0af78d3e06ee5c2c 9882cd47a54da008 ed69d2055556d28d
new  42aed1bd041b4902 51edb31afb63866a 974b4d53b18e3734 f4b3dff56bf49921
```

**FEILIAN-512, abc (24-bit), block 0, Hash digest output**

```
old  b69fc86f312df402 fd5d243c61ab3768 8572bbcdf2e7de28 e737707bf268fa8c
old  ee80551c87e0baef 6fa34ad98d022401 a535b6f14f4403ea 8c61fdc44d303d3f
new  fc7320c565f60ec6 a6ea26585f7c7d1f 50931119a1d1fb6c a06a71bed9bce094
new  7e22171373e48e0c 9bb1ef36808ef3e5 fa56c50ff5838213 b54a0750c6ae1270
```

**FEILIAN-512, a×129 (1032-bit), block 1, State v after 1 round**

```
old  1b92ba0b8ed9901e 322a6b7f6dbd961a 6f0d49fb7c9a3a93 74a0cb3fb47cfa1d
old  390c7d5bbc3ba40c 1492d64cfdcdff7f 7bdcae148043d613 1aebd1e247d78cce
old  28edfcc54a09cb4b c15e284378787b6f ea31511506e6663e fcb01b326cef2dd4
old  7acb3590069a33ac 0b769eaa73cc8aa8 f74b0b30628d4b86 029d6c134202ae50
new  1b92ba0b8ed9901e 322a6b7f6dbd961a 6f0d49fb7c9a3a93 74a0cb3fb47cfa1d
new  390c7d5bbc3ba40c 1492d64cfdcdff7f 7bdcae148043d613 1aebd1e247d78cce
new  28edfcc54a09cb4b c15e284378787b6f ea31511506e6663e fcb01b326cef2dd4
new  7acb3590069a33ac 0b769eaa73cc8aa8 f74b0b30628d4b86 029d6c134202a258
```

**FEILIAN-512, a×129 (1032-bit), block 1, State v after 2 rounds**

```
old  3997f897738d7264 27b0dc1245c2a115 27aa95af46e825f6 9735d72ed367270c
old  93c9c1cf4b6cb421 44b0d903ffa61493 a60bee4c41c043c2 4a599fb020f948a6
old  97e7be0a85f0b639 9c847ca1a6f5dd7d 41758cd34890b4d6 718cd67de1b5f5f2
old  f29d5170f4ddd1a1 65ce716253370974 13b547584216ce75 b22bbb780b459c5b
new  ca7d7e7f3bf549bd 3b42443a5daa0c30 a92cdeaa0ba0b49f 93fb8ff6781f1bd2
new  6349c1cf4b849c39 f94a9100779a50d0 d97c40024ba02996 a2a91fb020f9409e
new  9a9a9a0b4e06ace0 a33fab86a3c5e857 350dccd34890b0ca 09ccd67de1c1e1fe
new  65d1fdcb0c2ecbe5 69c6716253370974 13b547584216ce75 ca5f3b780b44e84c
```

**FEILIAN-512, a×129 (1032-bit), block 1, State v after 5 rounds**

```
old  899e8207f6607ea8 8799d5e5a5545db2 397cc1a08f80c9e8 5f1dc6d4c870afaa
old  5ffa715e10fa4ebb 7fcaa102cace2b96 c41ce5245283161d 2860fbc84c7827e0
old  f9050f5d1e0992f2 bbbe5a4b9e10870c 656e93cfdea6e795 dd1794d3b8495044
old  cc33144bfea4ac37 7201ae6d2d5003a7 825df5b4648495ba d5aea41083691228
new  7a9c4a471ead8d5b 915c0bd0538d5bc0 0c23ccff9c4ce7f8 14c8c897fe608559
new  3f924ad369b5b0f8 ed19e15bce87ce2e e0369f3626b675b1 31daa605d7c21cc0
new  8a0119ae710bae5f 216fb3fc2180497c 39f01131a543eb1a 677b3034dc954b44
new  8f19133a69d8b087 b8a7a6000da4758a ee27e4a16be3539f ff37367ff8bcb3d2
```

**FEILIAN-512, a×129 (1032-bit), block 1, State v after 10 rounds**

```
old  a3a66d718393b190 57a641b6f559ca28 14ae98ca821165c1 964924180c0c2aec
old  70e5c9163b9bb7b8 75f591d991ff9075 e032c9a487a0ebe5 5232eab7184dc473
old  4ba41a1226552766 1317a3c2f1febb79 106b9ccebf54179f 99a74034e10ea0d9
old  b4873adf9a5f8b08 b1110e17b9cbd657 2299b7ce044bdad0 eb2bde5268202f16
new  c76fc8b46fcecd5e 6219623481956093 80b7157a0ea6fde9 7f3cb34e39a0970a
new  97de4eaf58501b10 057628deebd5d8d6 57b6aeaefb510f1e d0f173e08c2fc5ea
new  d96f6d3231d2687a 9a5c436ef5615dcc 19a37a06bf6b8f70 931938e859214b2c
new  a793549ecae6e9b1 29f1ec4e40e84ed1 b8c6d17eb5abf35b 5b05c3107f0f7bed
```

**FEILIAN-512, a×129 (1032-bit), block 1, State v after 20 rounds**

```
old  b72bcb92da14a15c 438457a2083168f6 414a18d028582920 428b125f3a580ced
old  685fe170c68bdb74 47308caeb842ceab eb94c299dc518afa f4b8ca3ea11d82a9
old  212bf03ff7964073 4ff8d3a44387a998 7c0e7f06c70c1f9d b407a8379acee379
old  1bff5606cae55701 5ae9993390e82acd cfbd7f3e95e202d1 20fe47339ed1512a
new  36cf6853dfd3c131 190a80391b21e7d9 d15ff027fae6a70f 315c32b67ded7bcf
new  b04dcd60b8b2e588 44c1cf957c2b80a6 4c1eda42524b4e32 8287314c3504a20e
new  e792833e39433d7b dd59d517071be611 890bcd15392b7186 7cd263244a157ce2
new  d9bb395de0f59a95 d4589c1c88391e1b 6b4117e6a1a6000d f69bcc979a8065a7
```

**FEILIAN-512, a×129 (1032-bit), block 1, Hash digest output**

```
old  cf785e5010f69c0d c915a2b5404cd4ce 1171e38bd36f7a06 983166d3a067f4fd
old  c33110945c39af05 a5934a4c4df32790 f5ab0d2930769ccc f96ae2ac2360bf4c
new  a2189955d155788c e69ab2a6db9b5a94 3eff5d5924876f96 ba46d3944947238e
new  3f0f29ea4c15bddd a8dd238876b0d693 3d6f17a7eb6e166b 5e4afb38519b803a
```
