# R8 — 共享测试基础设施（ICCS 归属的 DRNG 与 KAT 支持代码）缺陷评估

**日期**：2026-09-28 · **对象**：FEILIAN 提交包（NGCC，2026-09-20）中的共享支持代码
**工具链**：gcc 15.2.0 (MinGW-w64, x86-64) · Windows · 16 GB RAM
**结论一句话**：R8 的两句判断都成立——确有可移植性与错误传播缺陷、确实只影响向量生成可靠性、确实不改变已固定的 message/digest 对。缺陷共定位 4 条可移植性 + 6 条错误传播，其中 **2 条是高危**（失败被当作成功、失败后被当作有效状态），我已给出可应用的补丁并验证其对官方向量零影响。

---

## 1. 范围与基线核对

R8 指向的是每个变体目录里那三份**由 ICCS 提供、六个变体完全相同**的文件：

| 文件 | 角色 | 大小 | 换行 |
|---|---|---|---|
| `drng.c` | 基于 SM3 的确定性随机数发生器（向量消息来源） | 11239 B | LF |
| `drng.h` | DRNG 接口与 `DRNG_ctx` | 1647 B | LF |
| `KAT_CryptHash.c` | KAT 生成器主程序 | 21469 B | **CRLF** |

核对结果（18 = 6 变体 × 3 文件）：

- 18 份文件 **sha256 两两相同**（`drng.c = 0df0ac78c828bd43…`、`drng.h = c4f85a800786e897…`、`KAT_CryptHash.c = ab4d08d943b3cfaf…`），
- 与官方提交包 `Implementations/` 下的同名文件 **逐字节相同**——此前的 C 侧修复完全没有触碰它们。

`Implementations/README.txt:47/57/63` 明确写着这三份文件 **SHALL NOT be modified**，参考实现声明为 **portable C99**，并给出文档化构建命令 `gcc -O2 -o kat.exe KAT_CryptHash.c CryptHash_AlgorithmInstance.c drng.c`，同时说明 `KAT_2_33` 需 ≥1 GB 内存。

**因此本项不做就地修改**，交付的是"缺陷报告 + 可直接应用的补丁"，与 R8 所述"应与基础设施提供方协调"一致。

---

## 2. 缺陷清单

### 2.1 可移植性

| # | 位置 | 事实 | 严重度 | 影响已发布向量？ |
|---|---|---|---|---|
| **P1** | `drng.c:36`（`L_SHIFT`），经 `drng.c:90/94` 触发 | 右移计数 `(32 - n)` 在 `n == 0` 时为 **32**，等于 32 位类型宽度 → **未定义行为**（C99 6.5.7p3）。`n == 0` 确实会被触发：`L_SHIFT(0x79cc4519U, i & 0x1F)` 中 `i` 遍历 0..63，`i == 0` 与 `i == 32` 时 `i & 0x1F == 0` | 中高 | 否（当前平台恰好无害，见 §3.1） |
| **P2** | 整个 SM3 核 | 把 `unsigned int` 当作恰好 32 位使用：`L_SHIFT` 硬编码 `32` 与 `0xFFFFFFFF`，`W[68]` 以 `unsigned int` 为单位，却**从不 `#include <stdint.h>`、不用 `uint32_t`、无静态断言** | 中 | 否（LP64/LLP64 下恰好成立） |
| **P3** | `drng.c:158` | 64 位长度字段高字写成 `block_num >> 32 << 9`，而正确是 `(block_num << 9) >> 32`——**两个移位操作数写反了**。二者仅当 `block_num` 为 `2^23` 的整数倍时相等 | 中（潜伏） | 否（DRNG 只哈希 55/56/59 字节，`block_num` 恒为 0） |
| **P4** | `drng.c:200-235`（`SM3_df`） | 结尾 `memcpy(input_string, temp, SEEDLEN)` **无条件**写回 55 字节，与入参 `input_string_len_bytes` 无关 → 真实前置条件是"缓冲区至少 55 字节"，参数表达不出来 | 中（潜伏内存安全） | 否（两处内部调用点按构造都满足） |

### 2.2 错误传播

| # | 位置 | 事实 | 严重度 |
|---|---|---|---|
| **E1** | `drng.c:252`、`drng.c:257` | `SM3_df(...)` 的返回值**被丢弃**；`drng.c:262` 无条件 `return DRNG_SUCCESS` | **高** |
| **E2** | `drng.c:216-221` + `232` + `250` | `SM3_df` 失败时在写回（`232`）**之前** return，而 `seed_material` 已在 `250` 被 `memset` 后又 `memcpy` 了原始种子 → Instantiate 把**调用方的原始种子材料原样当成 V**，跳过派生步骤，仍报成功 | **高** |
| **E3** | `KAT_CryptHash.c:296/379/487/601`、`301/410/518/602` | 8 处 `init_random_number()` / `get_random_number()` 返回值**全部未检查** | **高** |
| **E4** | `KAT_CryptHash.c:621` | `KAT_Loop` 主循环内 10⁶ 次 `CryptHash(...)` 的返回值未检查，而 `:604` 是检查的；失败会让 `digest` 保留上一次的值，循环照跑，最终写出一条**看似正常但无意义**的 `h_1000000` | **高** |
| **E5** | `drng.c:265-315` | `SM3_DRNG_Generate` **没有失败路径**（结束于 `return DRNG_SUCCESS`），`drng.h:41` 承诺的 `others for error` 在 Instantiate 之后形同虚设 | 中 |
| **E6** | `KAT_CryptHash.c:318-323 / 426-431 / 534-539 / 630-635` | `fclose` 失败直接覆盖 `rt`，把更具体的 `KAT_MEMORY_ALLOCATION_FAILED` 变成 `KAT_FILE_OPERATE_FAILED` | 低 |

### 2.3 与文件归属相关的杂项（不单独计缺陷，但建议一并处理）

- **EOL 不一致**：包内 `KAT_CryptHash.c` 是 CRLF，`drng.c`/`drng.h` 是 LF。导致 `patch` 直接拒绝 hunk（`Hunk #N FAILED … different line endings`），git diff 也容易整篇变动。
- `HIGH_N_BIT_MASK(N)` 在 `drng.c:31` 与 `KAT_CryptHash.c:40` **各定义一份**，靠人工同步。
- `SEED_LEN_BYTES 64`（`KAT_CryptHash.c:29`，不在任何头文件里）与 `SEEDLEN 55`（`drng.h:15`）无任何交叉校验。
- `fprint_message_partial` 用 `msg[msg_len_bits / 8 - 8 + i]`，当 `msg_len_bits < 64` 时下标下溢（当前调用点恒为 2²³/2³³，不触发）。

### 2.4 明确**没有**问题的部分（避免误报）

- **无字节序依赖**：SM3 核全部逐字节取数/写数（`(msg + i*4)[0] << 24 | …`、`PUT32`），大小端通吃。
- **语言层面无问题**：按 README 声明的 C99 与文档化命令构建，`-std=c99 -pedantic-errors`、`-Wall -Wextra` 均为 **0 error / 0 warning**（C89 会报错，但 README 声明的是 C99，不算缺陷）。
- **64 字节种子没有熵损失**（我最初怀疑被截断为 55）：`drng.c:215` 把 `1 + 4 + 64` 字节整体喂给 SM3，`SEEDLEN` 只限制**写回**长度。实测仅在末 9 字节不同的两个种子会得到完全不同的 V 与输出（§3.2）——此项**不是缺陷**。

---

## 3. 证据

探针 `r8_probe.c` 原样 `#include "drng.c"`（不改一行），并用文本层面的 `malloc` 拦截实现**确定性分配失败注入**。报告见 `R8_probe_report.txt`（14 项检查全通过）与 `R8_probe_report_patched.txt`（同一探针跑在已打补丁的代码上）。

### 3.1 P1：同一个表达式两个值

```
(0x79cc4519u & 0xFFFFFFFFu) >> 32        = 0x00000000   (计数编译期已知)
(0x79cc4519u & 0xFFFFFFFFu) >> (32 - 0)  = 0x79CC4519   (计数仅运行期已知)
```

两行是**同一个表达式、同一组值**，结果不同——这就是 UB 的特征。gcc 对可折叠形式直接给出 `warning: right shift count >= width of type [-Wshift-count-overflow]`（注意：在 `drng.c:90/94` 真实位置计数是 `i & 0x1F`，**文档化构建与 `-Wall -Wextra` 均不报**，是静默 UB）。

**为什么现在不炸**：`L_SHIFT(x, 0) = (x << 0) | (坏项) = x | 坏项`，两种可能的折叠（0 或 x）被 OR 吸收，都得到 `x`。256 组 (值, n) 扫描与严格定义的 `rotl32` **零不一致**。所以：**现状是"侥幸正确"，不是"正确"**。

### 3.2 P2 与 T2（种子路径）

`CHAR_BIT=8, sizeof(unsigned int)=4, UINT_MAX=0xFFFFFFFF` —— 本机恰好成立，代码里没有任何东西保证这一点。

仅末 9 字节不同的两个 64 字节种子 → `V = 5D6E308FA26AEFD0…` vs `CC5CF1A347D7E77C…`，输出 `1068440D…` vs `FF7876FD…`：**种子被完整消费**。

### 3.3 E1/E2：失败被当成成功（本项最严重的实证）

注入"`SM3_df` 内部申请 `data_to_SM3` 的那次 `malloc` 返回 NULL"（即分配调用序号 #1）：

| 观测 | 修复前 | 修复后 |
|---|---|---|
| `init_random_number()` 返回值 | **0（成功）** | **-2** |
| 全零种子时返回值 | **0** | **-2** |
| 失败后 `V`（Instantiate 时点快照） | `5A5B58595E5F5C5D…` = **调用方原始种子材料** | `0000000000000000…`（已清零） |
| 干净运行 `V` | `6A77F99164C98646…` | 同 |
| 全零种子 + 失败后 `V` | `0000000000000000…` | 同 |

即：失败时 **SM3 派生步骤被静默跳过，调用方的原始种子直接成为 DRNG 状态**，函数仍返回成功。这与我们在 `CryptHash` 里报过的 **10-1 是同一类结构缺陷**（成功码 + 形状合法的错误输出），而且更隐蔽——回退状态不是固定常量，而是调用方自己的种子，因此"错误"序列仍然确定、可复现。

### 3.4 E3/E4：端到端后果

复刻 `gen_KAT_2_12()` 首条向量（种子 = `"KAT_2_12"`×8，`msg_len_bits = 1024`）：

| | 干净运行 | DRNG 失败运行 |
|---|---|---|
| msg[0..15] | `D51F0EA2F230B5F7…` | `2CDCE3D697AF3716…` |
| digest[0..15] | `8A50105A46DA8B62…` | `65D15EB5C531EEF0…` |
| `init_random_number` | 0 | **0（修复前）/ -2（修复后）** |
| `CryptHash` | 0 | 0 |

生成器把消息与摘要直接写文件（`:302`、`:311`），进程以 `KAT_SUCCESS` 退出：**失败在输出里完全不可见**，4097 条向量只是"换了一整套同样格式正确的值"。这就是 R8 所说"影响向量生成可靠性"的确切含义。

### 3.5 P4：越界写回

以 16 字节缓冲区 + 64 字节哨兵调用 `SM3_df(buf, 16)`：**哨兵被改写 39 字节**（= `SEEDLEN - 16`），起始偏移 0。修复后该调用被拒绝（`ERROR: SM3_df() requires at least 55 bytes of input, got 16.`），改写字节数 0。

### 3.6 P3：长度字段

| block_num | 消息比特数 | 现行代码 | 正确值 |
|---|---|---|---|
| 0 / 1 / 8388607 | 0 / 512 / 4294966784 | `0x00000000` | `0x00000000` |
| 8388608 | 4294967296 | `0x00000000` | `0x00000001` ← 分叉 |
| 16777216 | 8589934592 | `0x00000000` | `0x00000002` ← 分叉 |

分叉始于 `block_num ≥ 2^23`，即 **≥512 MiB 的输入**；DRNG 只哈希 ≤59 字节，故为潜伏缺陷。

### 3.7 E3/E4 的静态位置

```
KAT_CryptHash.c  忽略 DRNG 返回值：296, 379, 487, 601  init_random_number(...)
                                 301, 410, 518, 602  get_random_number(...)
                 检查 CryptHash  ：303, 383, 397, 412, 491, 505, 520, 604
                 未检查 CryptHash：621（KAT_Loop 主循环内）
```

**额外关联**：在本次 C 侧修复之前，`CryptHash` 不可能失败，所以 `:621` 只是理论问题；修复后 `CryptHash` 会在补齐缓冲区分配失败时返回非零，`621` 遂成为**活的风险点**——两处修复需要一起看。

---

## 4. 修复建议

补丁：`iccs_patch/R8_iccs_support_code_FIX.patch`（11880 B，**20 个 hunk**：`drng.c` 7 个 + `KAT_CryptHash.c` 13 个；**不涉及 `drng.h`**）。
应用器：`iccs_patch/fix_support_code.py`（21 个编辑块 / 24 次替换，会断言每块的出现次数，按各文件原有换行符写入）。`patched_example/FEILIAN1024/` 是打好补丁的现成例子。

### 4.1 逐条对应

| 缺陷 | 补丁动作 |
|---|---|
| P1 | `L_SHIFT` 改写为 `((uint32_t)(a) << ((n) & 31)) \| ((uint32_t)(a) >> ((32u - (n)) & 31))`：`n == 0` 时定义为 `a`，不再移位 32 |
| P2 | 新增 `#include <stdint.h>`，旋转显式用 `uint32_t`（不再依赖 `unsigned int` 的宽度） |
| P3 | `PUT32(block + 56, (block_num << 9) >> 32)` |
| P4 | `SM3_df` 开头前置条件检查，返回新错误码 `DRNG_INVALID_LENGTH (-3)`；另加 `typedef` 静态断言保证 DF 块计数能装进 1 字节；`data_to_SM3[0] = (unsigned char)(counter & 0xFFU)` 显式化 |
| E1/E2 | 两次 `SM3_df` 的返回值均检查；失败时 `free` + 清零 `*drng` + 返回真实错误码 |
| E3 | 8 处 DRNG 调用全部检查，新增 `KAT_DRNG_FAILED (-5)`，失败即 `goto cleanup` |
| E4 | `:621` 的 `CryptHash` 返回值检查，失败置 `KAT_CRYPTHASH_FAILED` 并 `goto cleanup` |
| E5 | （不改函数签名）由 E1/E2 使失败在 Instantiate 处即被拦截，`Generate` 不再被以坏状态调用 |
| E6 | `fclose` 失败仅在 `rt == KAT_SUCCESS` 时改写错误码，保留首个错误 |
| 杂项 | `int main()` → `int main(void)` |

### 4.2 应用方式

```bash
# 方式一：GNU patch（补丁为 LF，包内 KAT_CryptHash.c 为 CRLF，必须加 -l）
cd <variant dir> && patch -p1 -l -i R8_iccs_support_code_FIX.patch

# 方式二：脚本（逐文件按原换行符写入，结果与方式一规范化后完全一致）
python fix_support_code.py --apply <variant dir>
```

验证：`patch -p1 -l` 返回 rc=0；其结果与脚本结果在 CRLF 规范化后 **完全一致**（`KAT_CryptHash.c` 696 行相同）。

---

## 5. 修复验证

### 5.1 诊断不回归

同一组严格选项（`-std=c99 -Wall -Wextra -pedantic -O2`）下，修复前/后均为 **0 warning**（`drng.c`、`drng.h`、`KAT_CryptHash.c`）。

### 5.2 缺陷确实消失

| 观测 | 修复前 | 修复后 |
|---|---|---|
| 分配失败后 `init_random_number()` | 0 | -2 |
| 失败后 `V` | 原始种子 `5A5B5859…` | `00000000…` |
| `SM3_df(buf,16)` 越界字节数 | 39 | 0 |
| 端到端失败运行的 init 返回 | 0 | -2 |

### 5.3 官方向量零回归

用**打了补丁**的 `drng.c` + `KAT_CryptHash.c`（配本次已修复的 `CryptHash_AlgorithmInstance.c`）按文档化命令重建官方生成器并重跑（FEILIAN512 64.6 s、FEILIAN1024 60.2 s，均 rc=0），4 类输出文件与官方 `Test_Vectors/` 逐字节比对：

| 文件 | 补丁后生成 sha256 | 官方 sha256 | 判定 |
|---|---|---|---|
| `KAT_2_12_FEILIAN512.txt` | `081f5e0640f66c15…` | `081f5e0640f66c15…` | **相同** |
| `KAT_2_23_FEILIAN512.txt` | `5041853221fbd24d…` | `5041853221fbd24d…` | **相同** |
| `KAT_2_33_FEILIAN512.txt` | `4c40596480c257c6…` | `4c40596480c257c6…` | **相同** |
| `KAT_Loop_FEILIAN512.txt` | `b4bcc6297d31e12e…` | `b4bcc6297d31e12e…` | **相同** |
| `KAT_2_12_FEILIAN1024.txt` | `8e5a2f485a79cd4a…` | `8e5a2f485a79cd4a…` | **相同** |
| `KAT_2_23_FEILIAN1024.txt` | `538ec522ebd235f0…` | `538ec522ebd235f0…` | **相同** |
| `KAT_2_33_FEILIAN1024.txt` | `c2710701f78493db…` | `c2710701f78493db…` | **相同** |
| `KAT_Loop_FEILIAN1024.txt` | `5ad6c080a68ba22f…` | `5ad6c080a68ba22f…` | **相同** |

**8/8 逐字节相同**——补丁对官方向量完全惰性，可安全接受。这也再次确认了官方 message/digest 对的有效性（6 个变体的共享代码同源，另 4 个变体的向量由 `KAT_current/checksums.sha256` 覆盖）。

---

## 6. 对 R8 措辞的判断

| R8 的原话 | 评估 |
|---|---|
| "has portability and error-propagation defects" | **成立**。可移植性 4 条（1 条 UB、1 条未固定字宽、2 条潜伏），错误传播 6 条，其中 4 条高危。 |
| "concern the reliability of vector generation" | **成立**，且可以量化：失败时函数返回成功、失败状态被当成有效状态、生成器 8 处调用点不检查、循环内 10⁶ 次哈希不检查，结果是一整套"格式正确、数值错误"的向量文件以成功码落盘。 |
| "should be coordinated with the infrastructure provider" | **成立且必要**。`Implementations/README.txt` 明文规定这三份文件 SHALL NOT be modified，提交方无权自行修改；本包已备好可直接应用的补丁。 |
| "do not invalidate the fixed message/digest pairs used in the review's conformance checks" | **成立**。见 §5.3：这些缺陷只在分配失败、非 x86-64/非 32 位 `int`、或 ≥512 MiB 输入时才改变数值；已发布的固定 message/digest 对全部保持有效。 |

### 建议向 ICCS 提出的事项

1. 采纳 `R8_iccs_support_code_FIX.patch`（或等价修改），重点是 **E1/E2 的失败传播**——这是唯一可能"静默产出错误向量"的路径。
2. 统一包内换行符（`KAT_CryptHash.c` 的 CRLF），并补一句构建契约（C99 + 已文档化的命令行）。
3. 把 `SEED_LEN_BYTES`（64）、`SEEDLEN`（55）、`HIGH_N_BIT_MASK`（重复定义）收敛到头文件，消除人工同步。
4. 若要彻底解决 P2，建议把 SM3 核的 32 位字显式声明为 `uint32_t`（本次补丁只做到"旋转不依赖 `unsigned int` 宽度"，`W[68]` 等仍为 `unsigned int`）。

---

## 7. 复现

```bash
# 1) 缺陷实证（原样 drng.c）
gcc -std=c11 -O2 -Wall -Wextra -I <variant dir> -o r8_probe.exe \
    r8_probe.c <variant dir>/CryptHash_AlgorithmInstance.c
./r8_probe.exe R8_probe_report.txt

# 2) 缺陷实证（已修复 drng.c，用于对照）
gcc -std=c11 -O2 -Wall -Wextra -I <fixed dir> -o r8_probe_patched.exe \
    r8_probe.c <fixed dir>/CryptHash_AlgorithmInstance.c
./r8_probe_patched.exe R8_probe_report_patched.txt

# 3) 打补丁 + 生成补丁 + 回归
python iccs_patch/fix_support_code.py --apply <scratch copy>
python iccs_patch/fix_support_code.py --diff  <clean copy> --patch-out iccs_patch/R8_iccs_support_code_FIX.patch
```

探针报告的判据约定：`[PASS]` = **缺陷存在**（探针是缺陷探测器）。因此在已修复的代码上，T3a/T3b/T5/T6 显示 `[FAIL]` 恰恰表示缺陷已被消除——对照请以 §3.3、§3.4、§3.5 的**原始数值**为准。
