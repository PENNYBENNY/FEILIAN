/*
Supplementary regression vectors for the FEILIAN implementations.

This file is NOT part of the NGCC KAT suite and does not replace it.  The
official KAT generator (KAT_CryptHash.c) prints the final byte of a message
through HIGH_N_BIT_MASK, so the bits that lie outside Msg_Len are erased before
they reach the output.  That is why the official vectors cannot distinguish a
correct implementation from one that lets those bits leak into the digest.

This generator prints the message bytes verbatim, so the vectors below fail on
the pre-fix code and pass on the fixed code.

  Family A  partial-byte equivalence   (regression guard for hash-10-4)
            The two messages agree in every bit inside Msg_Len and disagree
            only in the low-order bits of the final byte.  A conformant
            implementation MUST return the same digest for both.

  Family B  length binding              (regression guard for hash-10-3)
            Each pair zero-pads to the same byte string but declares different
            lengths.  Under the true-cumulative-length counter the digests MUST
            differ; a padded-length counter collapses each pair to one digest.

  Family C  error paths                 (regression guard for hash-10-1 / 10-5)
            Declared lengths the padding arithmetic cannot serve.  CryptHash
            MUST return non-zero and MUST NOT write the output buffer.

Build:
    gcc -O2 -I<variant_dir> KAT_Supplemental.c <variant_dir>/CryptHash_AlgorithmInstance.c -o katsup
Run:
    ./katsup <output_file>
*/

#include <limits.h>
#include <stdio.h>
#include <string.h>

#include "CryptHash_AlgorithmInstance.h"

#define MSG_BUF_BYTES 4096
#define DIG_BUF_BYTES 128

static unsigned char g_msg[MSG_BUF_BYTES];
static unsigned char g_dig[DIG_BUF_BYTES];

static const unsigned long long g_partial_bits[] = {
    1ULL, 2ULL, 3ULL, 4ULL, 5ULL, 6ULL, 7ULL,
    9ULL, 15ULL, 17ULL, 1023ULL, 1025ULL, 1031ULL, 2049ULL
};

static void fill_pattern(unsigned long long bytes)
{
    unsigned long long i;
    for (i = 0; i < bytes; i++)
    {
        g_msg[i] = (unsigned char)(0x31ULL + ((i * 37ULL + 11ULL) % 0xB0ULL));
    }
}

/* Print (bits + 7) / 8 bytes verbatim: no masking of the final byte, so a
   difference in the bits outside Msg_Len stays visible. */
static void put_msg(FILE *fp, const char *tag, unsigned long long bits)
{
    unsigned long long i;
    unsigned long long bytes = (bits + 7ULL) / 8ULL;

    fprintf(fp, "%s = ", tag);
    for (i = 0; i < bytes; i++)
    {
        fprintf(fp, "%02X", g_msg[i]);
    }
    if (bytes == 0)
    {
        fprintf(fp, "(empty)");
    }
    fprintf(fp, "\n");
}

static void put_dig(FILE *fp, const char *tag)
{
    int i;
    fprintf(fp, "%s = ", tag);
    for (i = 0; i < DIGEST_BIT_LENGTH / 8; i++)
    {
        fprintf(fp, "%02X", g_dig[i]);
    }
    fprintf(fp, "\n");
}

static int hash_into_dig(unsigned long long bits)
{
    int i;
    for (i = 0; i < DIG_BUF_BYTES; i++)
    {
        g_dig[i] = 0xAA;               /* sentinel: a failed call must not touch it */
    }
    return CryptHash(DIGEST_BIT_LENGTH, g_msg, bits, g_dig);
}

static int digest_is_sentinel(void)
{
    int i;
    for (i = 0; i < DIGEST_BIT_LENGTH / 8; i++)
    {
        if (g_dig[i] != 0xAA) return 0;
    }
    return 1;
}

/* ------------------------------------------------------------------ */

static void family_a(FILE *fp)
{
    unsigned long long k, bits, bytes, last;
    unsigned char mask, base, dig_a[DIG_BUF_BYTES];
    int n = 0;

    for (k = 0; k < sizeof(g_partial_bits) / sizeof(g_partial_bits[0]); k++)
    {
        bits = g_partial_bits[k];
        bytes = (bits + 7ULL) / 8ULL;
        last = bytes - 1ULL;
        mask = (unsigned char)((bits % 8ULL) ? (0xFFU << (8 - (bits % 8ULL))) : 0xFFU);

        fill_pattern(bytes);
        base = g_msg[last];

        /* A: the bits outside Msg_Len are zero */
        g_msg[last] = (unsigned char)(base & mask);
        if (hash_into_dig(bits) != 0)
        {
            fprintf(fp, "Case = A%d\nERROR = CryptHash returned non-zero\n\n", ++n);
            continue;
        }
        memcpy(dig_a, g_dig, sizeof(dig_a));

        /* B: the same bits are one; everything inside Msg_Len is unchanged */
        g_msg[last] = (unsigned char)((base & mask) | (unsigned char)(~mask));
        if (hash_into_dig(bits) != 0)
        {
            fprintf(fp, "Case = A%d\nERROR = CryptHash returned non-zero\n\n", ++n);
            continue;
        }

        fprintf(fp, "Case = A%d\n", ++n);
        fprintf(fp, "Note = partial byte: only the %llu low-order bits of the final byte differ\n",
                (unsigned long long)((bits % 8ULL) ? (8ULL - (bits % 8ULL)) : 0ULL));
        fprintf(fp, "Msg_Len = %llu\n", bits);
        g_msg[last] = (unsigned char)(base & mask);
        put_msg(fp, "Msg_A", bits);
        put_dig(fp, "Dst_A");
        g_msg[last] = (unsigned char)((base & mask) | (unsigned char)(~mask));
        put_msg(fp, "Msg_B", bits);
        put_dig(fp, "Dst_B");
        fprintf(fp, "Expect = SAME\n");
        fprintf(fp, "Verdict = %s\n\n", (memcmp(dig_a, g_dig, DIGEST_BIT_LENGTH / 8) == 0) ? "SAME" : "DIFFERENT");
    }
}

static void family_b(FILE *fp)
{
    unsigned char dig_a[DIG_BUF_BYTES];
    int i;

    /* B1: "abc" declared as 24 bits, versus the same bytes zero-padded and
       declared as 1024 bits.  One padded block either way; only Msg_Len moves. */
    memset(g_msg, 0, 128);
    g_msg[0] = 'a'; g_msg[1] = 'b'; g_msg[2] = 'c';
    if (hash_into_dig(24ULL) != 0) { fprintf(fp, "Case = B1\nERROR = CryptHash returned non-zero\n\n"); return; }
    memcpy(dig_a, g_dig, sizeof(dig_a));

    fprintf(fp, "Case = B1\n");
    fprintf(fp, "Note = same padded bytes, declared length differs\n");
    fprintf(fp, "Msg_Len_A = 24\n");
    put_msg(fp, "Msg_A", 24ULL);
    put_dig(fp, "Dst_A");

    memset(g_msg, 0, 128);
    g_msg[0] = 'a'; g_msg[1] = 'b'; g_msg[2] = 'c';
    if (hash_into_dig(1024ULL) != 0) { fprintf(fp, "ERROR = CryptHash returned non-zero\n\n"); return; }
    fprintf(fp, "Msg_Len_B = 1024\n");
    put_msg(fp, "Msg_B", 1024ULL);
    put_dig(fp, "Dst_B");
    fprintf(fp, "Expect = DIFFERENT\n");
    fprintf(fp, "Verdict = %s\n\n", (memcmp(dig_a, g_dig, DIGEST_BIT_LENGTH / 8) == 0) ? "SAME" : "DIFFERENT");

    /* B2: 129 bytes declared as 1032 bits, versus the same 129 bytes followed
       by 127 zero bytes declared as 2048 bits.  Two padded blocks either way;
       the second block's counter is the only difference. */
    memset(g_msg, 0, 256);
    for (i = 0; i < 129; i++) g_msg[i] = 'a';
    if (hash_into_dig(1032ULL) != 0) { fprintf(fp, "Case = B2\nERROR = CryptHash returned non-zero\n\n"); return; }
    memcpy(dig_a, g_dig, sizeof(dig_a));

    fprintf(fp, "Case = B2\n");
    fprintf(fp, "Note = same padded bytes, declared length differs in the final block\n");
    fprintf(fp, "Msg_Len_A = 1032\n");
    put_msg(fp, "Msg_A", 1032ULL);
    put_dig(fp, "Dst_A");

    memset(g_msg, 0, 256);
    for (i = 0; i < 129; i++) g_msg[i] = 'a';
    if (hash_into_dig(2048ULL) != 0) { fprintf(fp, "ERROR = CryptHash returned non-zero\n\n"); return; }
    fprintf(fp, "Msg_Len_B = 2048\n");
    put_msg(fp, "Msg_B", 2048ULL);
    put_dig(fp, "Dst_B");
    fprintf(fp, "Expect = DIFFERENT\n");
    fprintf(fp, "Verdict = %s\n\n", (memcmp(dig_a, g_dig, DIGEST_BIT_LENGTH / 8) == 0) ? "SAME" : "DIFFERENT");
}

static void case_c(FILE *fp, int n, unsigned long long bits)
{
    int rc;
    fill_pattern(64);
    rc = hash_into_dig(bits);
    fprintf(fp, "Case = C%d\n", n);
    fprintf(fp, "Note = declared length overflows the padding arithmetic\n");
    fprintf(fp, "Msg_Len = %llu\n", bits);
    fprintf(fp, "Dst_Len = %d\n", DIGEST_BIT_LENGTH);
    fprintf(fp, "Return = %d\n", rc);
    fprintf(fp, "Buffer_Untouched = %s\n", digest_is_sentinel() ? "YES" : "NO");
    fprintf(fp, "Expect = non-zero return, buffer untouched\n\n");
}

int main(int argc, char **argv)
{
    FILE *fp;

    if (argc < 2)
    {
        fprintf(stderr, "usage: %s <output_file>\n", argv[0]);
        return 2;
    }
    fp = fopen(argv[1], "wb");
    if (fp == NULL)
    {
        fprintf(stderr, "cannot open %s\n", argv[1]);
        return 2;
    }

    fprintf(fp, "# FEILIAN supplementary regression vectors (local set, not the NGCC KAT suite)\n");
    fprintf(fp, "# Implementation : %s\n", ALGORITHM_INSTANCE);
    fprintf(fp, "# Digest length  : %d bits\n", DIGEST_BIT_LENGTH);
    fprintf(fp, "# Messages are printed verbatim: unlike the official KAT format, the final\n");
    fprintf(fp, "# byte is NOT masked, so bits outside Msg_Len remain visible.\n");
    fprintf(fp, "# Family A  partial-byte equivalence  (hash-10-4)\n");
    fprintf(fp, "# Family B  length binding            (hash-10-3 counter convention)\n");
    fprintf(fp, "# Family C  error paths               (hash-10-1 / hash-10-5)\n");
    fprintf(fp, "\n");

    family_a(fp);
    family_b(fp);
    case_c(fp, 1, ULLONG_MAX);
    case_c(fp, 2, ULLONG_MAX - 4ULL);

    fclose(fp);
    return 0;
}
