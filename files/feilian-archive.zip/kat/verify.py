import hashlib, pathlib, re, sys

CUR = pathlib.Path(r'C:/Users/NETSCAPE/Desktop/FEILIEN.version/260928/KAT_current')
SUB = pathlib.Path(r'C:/Users/NETSCAPE/AppData/Local/Temp/feilian_sub/FEILIAN/Test_Vectors')

VARIANTS = ['FEILIAN512', 'FEILIAN768', 'FEILIAN1024',
            'FEILIAN_SIMD512', 'FEILIAN_SIMD768', 'FEILIAN_SIMD1024']
KINDS = ['KAT_2_12', 'KAT_2_23', 'KAT_2_33', 'KAT_Loop']
BITLEN = {'FEILIAN512': 512, 'FEILIAN_SIMD512': 512,
          'FEILIAN768': 768, 'FEILIAN_SIMD768': 768,
          'FEILIAN1024': 1024, 'FEILIAN_SIMD1024': 1024}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def count_vectors(p):
    n_msg = n_dst = 0
    for line in p.read_text(errors='replace').splitlines():
        if line.startswith('Msg_Len'): n_msg += 1
        elif line.startswith('Dst = '): n_dst += 1
    return n_msg, n_dst

print('=' * 96)
print('A. INVENTORY  (24 files, current code)')
print('=' * 96)
print('%-16s %-10s %12s %8s %8s  %s' % ('variant', 'kind', 'bytes', 'Msg', 'Dst', 'sha256'))
print('-' * 96)
inv = {}
for v in VARIANTS:
    for k in KINDS:
        p = CUR / v / 'output' / ('%s_%s.txt' % (k, v))
        if not p.exists():
            print('%-16s %-10s  MISSING' % (v, k)); continue
        nm, nd = count_vectors(p)
        h = sha(p)
        inv[(v, k)] = (p, h, p.stat().st_size, nm, nd)
        print('%-16s %-10s %12d %8d %8d  %s' % (v, k, p.stat().st_size, nm, nd, h[:16]))

print()
print('=' * 96)
print('B. REGRESSION vs submission Test_Vectors  (reference variants)')
print('=' * 96)
all_same = True
for v in ['FEILIAN512', 'FEILIAN768', 'FEILIAN1024']:
    for k in KINDS:
        a = SUB / ('%s_%s.txt' % (k, v))
        b = CUR / v / 'output' / ('%s_%s.txt' % (k, v))
        if not a.exists():
            print('  %-24s  (no baseline file)' % a.name); continue
        ha, hb = sha(a), sha(b)
        same = ha == hb
        all_same &= same
        print('  %-30s %s   %s' % (a.name, 'IDENTICAL' if same else 'DIFFERENT', hb[:16]))
print('  --> all reference KAT files', 'MATCH the submission' if all_same else 'DIFFER from the submission')

print()
print('=' * 96)
print('C. CROSS-CHECK  reference vs SIMD  (same digest length)')
print('=' * 96)
for ref, simd in [('FEILIAN512','FEILIAN_SIMD512'), ('FEILIAN768','FEILIAN_SIMD768'),
                  ('FEILIAN1024','FEILIAN_SIMD1024')]:
    ok = 0; bad = []
    for k in KINDS:
        a = CUR / ref / 'output' / ('%s_%s.txt' % (k, ref))
        b = CUR / simd / 'output' / ('%s_%s.txt' % (k, simd))
        if sha(a) == sha(b): ok += 1
        else: bad.append(k)
    print('  %-14s vs %-18s : %d/4 byte-identical  %s'
          % (ref, simd, ok, ('mismatch: ' + ','.join(bad)) if bad else ''))

print()
print('=' * 96)
print('D. 2_12 COVERAGE / EDGE VECTORS')
print('=' * 96)
for v in ['FEILIAN512', 'FEILIAN1024']:
    p = CUR / v / 'output' / ('KAT_2_12_%s.txt' % v)
    lens = [int(m.group(1)) for m in re.finditer(r'^Msg_Len = (\d+)', p.read_text(), re.M)]
    print('  %-12s vectors=%d  L=%d..%d  contiguous=%s'
          % (v, len(lens), min(lens), max(lens), lens == list(range(0, 4097))))
    one = [L for L in lens if L < 8]
    print('               sub-byte lengths present: %s' % one)
