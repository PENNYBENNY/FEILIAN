import pathlib, re

R = pathlib.Path('.')
VARIANTS = ['FEILIAN512','FEILIAN768','FEILIAN1024',
            'FEILIAN_SIMD512','FEILIAN_SIMD768','FEILIAN_SIMD1024']

def parse(p):
    cases, cur = {}, None
    for line in p.read_text().splitlines():
        m = re.match(r'^Case = (\S+)', line)
        if m:
            cur = m.group(1); cases[cur] = {}; continue
        if cur is None: continue
        if ' = ' in line:
            k, v = line.split(' = ', 1)
            cases[cur][k.strip()] = v.strip()
        elif line.startswith('Return = '):
            cases[cur]['Return'] = line.split('=',1)[1].strip()
    return cases

print('%-16s %-30s %-30s' % ('variant', 'FIXED code (current)', 'BASELINE code (pre-fix)'))
print('-'*80)
tot_a = tot_c = 0
for v in VARIANTS:
    a = parse(R/v/'output'/('KAT_Supplemental_%s.txt' % v))
    b = parse(R/'_before_fix'/('KAT_Supplemental_%s.txt' % v))
    va = [k for k in a if k.startswith('A') and a[k].get('Verdict') == 'SAME']
    vb = [k for k in b if k.startswith('B') and b[k].get('Verdict') == 'DIFFERENT']
    ca = [k for k in a if k.startswith('C') and a[k].get('Return') == '-1']
    ca_untouched = [k for k in a if k.startswith('C') and a[k].get('Buffer_Untouched') == 'YES']
    va_bad = [k for k in a if k.startswith('A') and a[k].get('Verdict') != 'SAME']
    vb_bad = [k for k in b if k.startswith('B') and b[k].get('Verdict') != 'DIFFERENT']
    cb = [k for k in b if k.startswith('C')]
    cb_wrong = [k for k in cb if b[k].get('Return') != '-1' or b[k].get('Buffer_Untouched') != 'YES']
    nA = sum(1 for k in a if k.startswith('A'))
    nC = sum(1 for k in a if k.startswith('C'))
    tot_a += nA; tot_c += nC
    print('%-16s A: %2d/%2d SAME%s   B: %d/%d DIFF   C: %d/%d rc=-1, all untouched=%s'
          % (v, len(va), nA, (' [BAD:'+','.join(va_bad)+']') if va_bad else '',
             len(vb), sum(1 for k in b if k.startswith('B')),
             len(ca), nC, len(ca_untouched) == nC))
    print('%-16s   baseline: A SAME=%d/%d   C wrong=%s'
          % ('', sum(1 for k in b if k.startswith('A') and b[k].get('Verdict')=='SAME'), nA,
             (','.join(cb_wrong) if cb_wrong else 'none')))

print()
print('--- detail, FEILIAN512: baseline vs fixed ---')
a = parse(R/'FEILIAN512'/'output'/'KAT_Supplemental_FEILIAN512.txt')
b = parse(R/'_before_fix'/'KAT_Supplemental_FEILIAN512.txt')
for k in sorted(set(a) | set(b), key=lambda s: (s[0], int(s[1:]))):
    x = a.get(k, {}); y = b.get(k, {})
    if k[0] == 'A':
        print('  %-4s Msg_Len=%-6s fixed=%s  baseline=%s'
              % (k, x.get('Msg_Len',''), x.get('Verdict',''), y.get('Verdict','')))
    elif k[0] == 'B':
        print('  %-4s Msg_Len=%-5s vs %-5s  fixed=%s  baseline=%s'
              % (k, x.get('Msg_Len_A',''), x.get('Msg_Len_B',''),
                 x.get('Verdict',''), y.get('Verdict','')))
    else:
        print('  %-4s Msg_Len=%-22s fixed: Return=%s Untouched=%s   baseline: Return=%s Untouched=%s'
              % (k, x.get('Msg_Len',''), x.get('Return',''), x.get('Buffer_Untouched',''),
                 y.get('Return',''), y.get('Buffer_Untouched','')))

print()
print('--- baseline C1 digest (should be the IV if the failure is silently swallowed) ---')
print('  fixed    C1 digest is absent from the file (no digest is printed for family C)')
print('  baseline Return =', b['C1'].get('Return'), ' Buffer_Untouched =', b['C1'].get('Buffer_Untouched'))
