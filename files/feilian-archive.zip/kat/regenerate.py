"""Regenerate every FEILIAN test-vector file from the current sources.

Two suites are produced:

  1. the official NGCC KAT suite (KAT_CryptHash.c + drng.c, unmodified),
     written to KAT_current/<VARIANT>/output/
  2. the supplementary regression vectors (KAT_Supplemental.c, local), which
     exercise the partial-byte and error-path behaviour that the official
     generator structurally cannot reach, written next to them

Optionally the supplementary suite is also built against a pre-fix baseline
tree so the two sets can be compared (--baseline).

Usage:
    python regenerate.py [--baseline <Implementations dir>] [--skip-official]

Run from anywhere; paths are resolved relative to this file.  Verified with
gcc 15.2 (MinGW-w64) on Windows.
"""

import argparse
import pathlib
import subprocess
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
IMPL = HERE.parent / 'Implementations'

VARIANTS = [
    ('FEILIAN512',     'Reference_Implementation/FEILIAN512',     []),
    ('FEILIAN768',     'Reference_Implementation/FEILIAN768',     []),
    ('FEILIAN1024',    'Reference_Implementation/FEILIAN1024',    []),
    ('FEILIAN_SIMD512',  'Optimized_Implementation/FEILIAN_SIMD512',  ['-mavx2']),
    ('FEILIAN_SIMD768',  'Optimized_Implementation/FEILIAN_SIMD768',  ['-mavx2']),
    ('FEILIAN_SIMD1024', 'Optimized_Implementation/FEILIAN_SIMD1024', ['-mavx2']),
]

BUILD = HERE / '_build'


def run(cmd, cwd=None):
    return subprocess.run([str(c) for c in cmd], cwd=cwd,
                          capture_output=True, text=True)


def build_official(impl_dir, rel, flags, out_exe):
    src = impl_dir / rel
    r = run(['gcc', '-O2', *flags, '-I', src, src / 'KAT_CryptHash.c',
             src / 'CryptHash_AlgorithmInstance.c', src / 'drng.c', '-o', out_exe])
    return out_exe, r


def build_supplemental(impl_dir, rel, flags, out_exe):
    src = impl_dir / rel
    r = run(['gcc', '-O2', *flags, '-I', src, HERE / 'KAT_Supplemental.c',
             src / 'CryptHash_AlgorithmInstance.c', '-o', out_exe])
    return out_exe, r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--baseline', default=None,
                    help='pre-fix Implementations directory, for the before/after run')
    ap.add_argument('--skip-official', action='store_true',
                    help='only regenerate the supplementary suite')
    args = ap.parse_args()

    BUILD.mkdir(exist_ok=True)

    if not args.skip_official:
        print('== official KAT suite ==')
        for name, rel, flags in VARIANTS:
            runt = HERE / name
            (runt / 'output').mkdir(parents=True, exist_ok=True)
            exe, r = build_official(IMPL, pathlib.Path(rel), flags,
                                    BUILD / ('kat_%s.exe' % name))
            if r.returncode != 0:
                print('  %-18s BUILD FAILED\n%s' % (name, r.stderr[:400]))
                continue
            t0 = time.time()
            with open(runt / 'run.log', 'w') as log:
                p = subprocess.run([str(exe)], cwd=runt, stdout=log,
                                   stderr=subprocess.STDOUT, text=True)
            n = len(list((runt / 'output').glob('*.txt')))
            print('  %-18s rc=%d  %.0fs  files=%d' % (name, p.returncode, time.time() - t0, n))

    print('== supplementary vectors (current code) ==')
    for name, rel, flags in VARIANTS:
        runt = HERE / name
        (runt / 'output').mkdir(parents=True, exist_ok=True)
        exe, r = build_supplemental(IMPL, pathlib.Path(rel), flags, BUILD / ('sup_%s.exe' % name))
        if r.returncode != 0:
            print('  %-18s BUILD FAILED\n%s' % (name, r.stderr[:400]))
            continue
        subprocess.run([str(exe), str(runt / 'output' / ('KAT_Supplemental_%s.txt' % name))])
        print('  %-18s ok' % name)

    if args.baseline:
        base = pathlib.Path(args.baseline).resolve()
        outdir = HERE / '_before_fix'
        outdir.mkdir(exist_ok=True)
        print('== supplementary vectors (baseline: %s) ==' % base)
        for name, rel, flags in VARIANTS:
            exe, r = build_supplemental(base, pathlib.Path(rel), flags,
                                        BUILD / ('supbase_%s.exe' % name))
            if r.returncode != 0:
                print('  %-18s BUILD FAILED' % name)
                continue
            subprocess.run([str(exe), str(outdir / ('KAT_Supplemental_%s.txt' % name))])
            print('  %-18s ok' % name)

    print('== verification ==')
    for script in ('verify.py', 'compare_sup.py'):
        if (HERE / script).exists():
            p = subprocess.run([sys.executable, script], cwd=HERE,
                               capture_output=True, text=True)
            print('-- %s --' % script)
            print(p.stdout)
            if p.returncode != 0:
                print(p.stderr[-800:])


if __name__ == '__main__':
    main()
