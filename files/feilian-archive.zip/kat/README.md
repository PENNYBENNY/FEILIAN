# KAT_current — 用当前代码重新生成的测试向量

本目录是用 `260928/Implementations/` 里**当前（已修正）**的实现重新跑出的全套测试向量。

生成日期：2026-09-28 · 工具链：gcc 15.2.0 (MinGW-w64, x86-64) · 平台：Windows

---

## 1. 目录内容

每个变体一个目录，`output/` 下 5 个文件：

| 文件 | 来源 | 内容 |
|---|---|---|
| `KAT_2_12_<V>.txt` | 官方 `KAT_CryptHash.c` | 0 … 4096 bit 全部 4097 个长度，每长度一条向量 |
| `KAT_2_23_<V>.txt` | 同上 | 2^23 bit（1 MB）消息 × 3 条（全 0 / 全 1 / 随机） |
| `KAT_2_33_<V>.txt` | 同上 | 2^33 bit（1 GB）消息 × 3 条 |
| `KAT_Loop_<V>.txt` | 同上 | 2^13 bit 消息迭代 10^6 次后的摘要 |
| `KAT_Supplemental_<V>.txt` | 本地 `KAT_Supplemental.c` | 补充回归向量，见第 4 节 |

`_before_fix/` 是同一套补充向量在**修复前**基线（官方提交包 2026-09-20 的源码）上的输出，仅用于对照。

```
KAT_current/
├── FEILIAN512/output/          FEILIAN768/output/          FEILIAN1024/output/
├── FEILIAN_SIMD512/output/     FEILIAN_SIMD768/output/     FEILIAN_SIMD1024/output/
├── _before_fix/                修复前基线的补充向量（对照用）
├── KAT_Supplemental.c          补充向量生成器
├── regenerate.py               一键重跑：编译 → 生成 → 校验
├── verify.py                   官方套件的清点 / 基线比对 / ref-SIMD 交叉比对
└── compare_sup.py              补充向量的修复前 vs 修复后判定
```

`KAT_CryptHash.c`、`drng.c`、`drng.h` 均未改动（规范要求 SHALL NOT be modified），
RTL 目录也没有参与本次生成。

---

## 2. 重跑

```bash
cd KAT_current
python regenerate.py --baseline <修复前的 Implementations 目录>
```

`--baseline` 可省略（省略后不生成 `_before_fix/`）；`--skip-official` 只重跑补充向量。
官方套件 6 个变体合计约 6 分钟（512 约 56 s、768 约 59 s、1024 约 94 s、SIMD 36–48 s），
2^33 那一步需要约 1.1 GB 可用内存。

---

## 3. 验证结果

### 3.1 与提交包基线逐字节一致（零回归）

12 个参考变体文件（512/768/1024 × 4 类）与提交包 `Test_Vectors/` 中的同名文件
**sha256 完全相同**。修正点（末字节 mask、失败返回、溢出检查）对官方 KAT 全部零影响 ——
原因是 KAT 生成器的 `get_random_number` 本来就用 `HIGH_N_BIT_MASK` 清掉了末字节的无效低位，
所以官方向量的输入从不触发这些分支。

| 文件 | sha256（前 16 位） |
|---|---|
| `KAT_2_12_FEILIAN512.txt` | `081f5e0640f66c15` |
| `KAT_2_23_FEILIAN512.txt` | `5041853221fbd24d` |
| `KAT_2_33_FEILIAN512.txt` | `4c40596480c257c6` |
| `KAT_Loop_FEILIAN512.txt` | `b4bcc6297d31e12e` |
| `KAT_2_12_FEILIAN768.txt` | `27f9d89927d7f0ea` |
| `KAT_2_23_FEILIAN768.txt` | `a989d5abc78f7de2` |
| `KAT_2_33_FEILIAN768.txt` | `5fec299cc76a3af4` |
| `KAT_Loop_FEILIAN768.txt` | `d2f58275f10dd333` |
| `KAT_2_12_FEILIAN1024.txt` | `8e5a2f485a79cd4a` |
| `KAT_2_23_FEILIAN1024.txt` | `538ec522ebd235f0` |
| `KAT_2_33_FEILIAN1024.txt` | `c2710701f78493db` |
| `KAT_Loop_FEILIAN1024.txt` | `5ad6c080a68ba22f` |

### 3.2 参考实现与 SIMD 实现交叉一致

每个摘要长度下 4 类文件 **4/4 逐字节相同**（512、768、1024 各一组）。
注意 DRNG 的种子取自文件名的前 8 字节（`"KAT_2_12"`），与变体名无关，
所以同一摘要长度的两个实现拿到的是完全相同的消息序列 —— 这是可直接比较的前提。

### 3.3 生成确定性

整套向量独立重跑两次，36 个文件（24 官方 + 6 当前补充 + 6 基线补充）**逐字节相同**。

### 3.4 覆盖完整性

`KAT_2_12` 各变体均为 4097 条，`Msg_Len` 恰好连续覆盖 `0 … 4096`，
其中 `0,1,2,3,4,5,6,7` 这 8 个非字节对齐（含空消息）长度都在。

---

## 4. 补充向量：官方 KAT 结构上看不到的部分

官方生成器用 `HIGH_N_BIT_MASK` 打印末字节（`KAT_CryptHash.c:198-201`），
**在输出之前就把 `Msg_Len` 之外的位抹掉了**。所以官方 KAT 在结构上无法区分
"正确实现" 和 "让这些位泄漏进摘要的实现" —— 本次修的两处缺陷它一条也测不出。

`KAT_Supplemental.c` 逐字节原样打印消息（不做 mask），据此设三组：

| 组 | 内容 | 判据 |
|---|---|---|
| A | 14 个长度（1,2,3,4,5,6,7,9,15,17,1023,1025,1031,2049），每例两条消息只在末字节的无效低位不同 | 两条摘要**必须相同** |
| B | 2 例：零填充后字节串相同、声明长度不同（24 vs 1024；1032 vs 2048） | 两条摘要**必须不同** |
| C | 2 例：声明长度超出补齐算术可处理范围（`ULLONG_MAX`、`ULLONG_MAX-4`） | 必须**非零返回**且**不写输出缓冲** |

### 修复前 vs 修复后

| 变体 | 修复后 | 修复前基线 |
|---|---|---|
| FEILIAN512 | A 14/14 SAME · B 2/2 DIFFERENT · C 2/2 rc=-1 且缓冲未动 | A **0/14** SAME · C **返回 0 且缓冲被改写** |
| FEILIAN768 | 同上 | 同上 |
| FEILIAN1024 | 同上 | 同上 |
| FEILIAN_SIMD512/768/1024 | 同上 | 同上 |

基线在 C 组的表现正是 hash-10-1：`CryptHash` 返回 0（成功），
却把 IV 当作摘要写进了调用方的缓冲区。

### 附带一个口径交叉印证

B 组的四条摘要恰好把 Appendix B 的分歧并排展示出来了（以下均为 FEILIAN-512）：

| 用例 | 声明长度 | 本目录产出的摘要（前 64 bit） | 对应 |
|---|---|---|---|
| B1 | 24 bit，消息 `616263` | `fc7320c565f60ec6…` | **修订版** Appendix B 的 `abc` 值 |
| B1 | 1024 bit，同一字节串补零 | `b69fc86f312df402…` | **原印刷** Appendix B 的 `abc` 值 |
| B2 | 1032 bit，129 字节 `a` | `a2189955d155788c…` | **修订版** Appendix B 的 `a×129` 值 |
| B2 | 2048 bit，同 129 字节后补零 | `cf785e5010f69c0d…` | **原印刷** Appendix B 的 `a×129` 值 |

也就是说：原印刷的那两个值，正好等于"把同一段字节补零到整块、并按填充长度计数"的结果。
这是对 Appendix B 修订结论的一次独立复核（详见 `../AppendixB_conformance_note.md`）。

---

## 5. 与其它产物的关系

| 文件 | 说明 |
|---|---|
| `../CodeChanges_summary.md` | C 侧 12 个文件的逐 hunk 改动说明 |
| `../CodeChanges_unified.diff` | 相对提交包的完整 unified diff |
| `../AppendixB_test_vectors_revised.txt` | 规范 Appendix B 完整中间状态的修订版 |
| `../AppendixB_revision_diff.md` | Appendix B 24 处数值变更对照 |

## 6. 已知限制

- `KAT_2_33` 需要约 1.1 GB 可用内存，低内存机器上会 `malloc` 失败并退出（`rc=-2`）。
- `KAT_Loop` 依赖 `CryptHash` 在 10^6 次调用中的累计行为，是最慢的一步（1024 变体约 90 s 中的大部分）。
- 补充向量是本目录定义的本地格式，不是 NGCC 官方格式，不要当作提交件使用。
- RTL 四核未参与生成，三处产物（规范附录 / C+KAT / RTL）的计数器口径目前仍不一致。
