import re, json, pathlib

SRC = pathlib.Path('C:/Users/NETSCAPE/AppData/Local/Temp/feilian_spec/appendixB_printed.txt')
raw = SRC.read_text(encoding='utf-8').splitlines()

lines = []
for l in raw:
    s = l.strip()
    if not s: continue
    if s.startswith('===') and 'PAGE' in s: continue
    if re.fullmatch(r'\d{1,3}', s): continue          # page numbers
    lines.append(s)

HEX4 = re.compile(r'^[0-9a-f]{16}$')
sec = re.compile(r'^(IV|Constants|Round constants|Initial state of v|State v after (\d+) rounds?|Hash digest output|First compressionMessage block after padding|Second compressionMessage block after padding):?$')
var = re.compile(r'^(B\.[123])FEILIAN-(\d+)$')
ex  = re.compile(r'^(One-block|Two-block) message')

data = {}          # (variant, example, blockidx, section) -> [words]
cur_v = cur_e = cur_b = None
i = 0
pending = None
while i < len(lines):
    s = lines[i]
    m = var.match(s)
    if m:
        cur_v = m.group(2); i += 1; continue
    m = ex.match(s)
    if m:
        cur_e = 'abc' if m.group(1) == 'One-block' else 'a129'
        cur_b = 0; i += 1; continue
    m = sec.match(s)
    if m:
        name = m.group(1)
        if name.startswith('First'):
            cur_b = 0; name = 'message_block'
        elif name.startswith('Second'):
            cur_b = 1; name = 'message_block'
        # collect following hex tokens
        toks = []
        j = i + 1
        while j < len(lines) and HEX4.match(lines[j].split()[0] if lines[j].split() else ''):
            row = lines[j].split()
            if not all(HEX4.match(t) for t in row): break
            toks.extend(row); j += 1
        data[(cur_v, cur_e, cur_b, name)] = toks
        i = j; continue
    i += 1

print('sections parsed:', len(data))
for k in sorted(data, key=lambda t: (t[0], t[1], t[2], t[3])):
    print(k, len(data[k]), data[k][:1])
json_out = { '|'.join(map(str,k)): v for k, v in data.items() }
pathlib.Path('printed_sections.json').write_text(json.dumps(json_out, indent=1), encoding='utf-8')
