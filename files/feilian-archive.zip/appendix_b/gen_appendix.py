import json, pathlib, re

SPEC = pathlib.Path('C:/Users/NETSCAPE/AppData/Local/Temp/feilian_spec/appendixB_printed.txt')
OUTDIR = pathlib.Path('C:/Users/NETSCAPE/Desktop/FEILIEN.version/260928')

RAW = SPEC.read_text(encoding='utf-8').splitlines()
clean = []
for l in RAW:
    s = l.strip()
    if not s:
        continue
    if s.startswith('===') and 'PAGE' in s:
        continue
    if re.fullmatch(r'\d{1,3}', s):
        continue
    clean.append(s)

HEX4 = re.compile(r'^[0-9a-f]{16}$')
LABEL_PREFIXES = ['IV:', 'Constants:', 'Round constants:',
                  'Message block after padding:',
                  'First compressionMessage block after padding:',
                  'Second compressionMessage block after padding:',
                  'Initial state of v:', 'State v after ', 'Hash digest output:']

items = []          # (kind, payload)
for s in clean:
    m = re.match(r'^(B\.[123])FEILIAN-(\d+)$', s)
    if m:
        items.append(('variant', m.group(2))); continue
    if s.startswith('One-block message') or s.startswith('Two-block message'):
        items.append(('example', 'abc' if s.startswith('One-block') else 'a129')); continue
    if any(s.startswith(p) for p in LABEL_PREFIXES):
        items.append(('label', s)); continue
    toks = s.split()
    if len(toks) == 4 and all(HEX4.match(t) for t in toks):
        items.append(('data', toks)); continue
    items.append(('text', s))


def parse_trace(p):
    out = {}
    cur = msg = blk = lab = None
    for line in pathlib.Path(p).read_text().splitlines():
        t = line.strip()
        if t.startswith('MSG '):
            msg = t.split()[1]; continue
        if t.startswith('BLOCK '):
            blk = int(t.split()[1]); cur = out.setdefault((msg, blk), {}); continue
        if t.startswith('DIGEST '):
            cur['DIGEST'] = t.split()[1]; continue
        if t.startswith('DOMAIN '):
            continue
        if t in ('INIT', 'FINAL') or re.fullmatch(r'ROUND \d+', t):
            lab = t; cur[lab] = []; continue
        parts = t.split()
        if cur is not None and lab and len(parts) == 4 and all(HEX4.match(x) for x in parts):
            cur[lab].extend(parts)
    return out


TRACE = {v: parse_trace('trace_%s.txt' % v) for v in ('512', '768', '1024')}


def dig_words(h):
    return [h[i:i + 16] for i in range(0, len(h), 16)]


# walk the printed structure, rebuild every block from the implementation
out_lines = []
changes = []
cur_v = cur_e = None
blk_idx = 0
i = 0
while i < len(items):
    kind, payload = items[i]
    if kind == 'variant':
        cur_v = payload; blk_idx = 0
        out_lines.append('B.%sFEILIAN-%s' % ({'1024': '1', '768': '2', '512': '3'}[payload], payload))
        i += 1; continue
    if kind == 'example':
        cur_e = payload; blk_idx = 0
        out_lines.append('One-block message: \u201cabc\u201d(24-bit)' if payload == 'abc'
                         else 'Two-block message: \u201caaa\u00b7\u00b7\u00b7aaa\u201d(1032-bit)')
        i += 1; continue
    if kind == 'text':
        out_lines.append(payload); i += 1; continue
    if kind == 'data':
        out_lines.append(' '.join(payload)); i += 1; continue
    if kind == 'label':
        label = payload
        # gather following data rows (4 words each)
        rows = []
        j = i + 1
        while j < len(items) and items[j][0] == 'data':
            rows.append(items[j][1]); j += 1
        printed_words = [w for r in rows for w in r]
        is_second = label.startswith('Second')
        if is_second:
            blk_idx = 1
        elif label.startswith('First') or label.startswith('Message block after padding'):
            blk_idx = 0
        cfg = TRACE[cur_v][({'abc': 'abc', 'a129': 'a_times_129'}[cur_e], blk_idx)]

        new_words = None
        if 'Message block after padding' in label:
            new_words = printed_words                       # unchanged
        elif label == 'Initial state of v:':
            new_words = printed_words                       # unchanged (independent of t)
        elif label.startswith('State v after'):
            n = re.search(r'after (\d+) rounds?', label).group(1)
            new_words = cfg['ROUND ' + n]
        elif label.startswith('Hash digest output'):
            new_words = dig_words(cfg['DIGEST'])

        out_lines.append(label)
        if new_words is None:
            for r in rows:
                out_lines.append(' '.join(r))
        else:
            for k in range(0, len(new_words), 4):
                out_lines.append(' '.join(new_words[k:k + 4]))
            if new_words != printed_words:
                changes.append({'variant': cur_v, 'example': cur_e, 'block': blk_idx,
                                'section': label, 'old': printed_words, 'new': new_words})
        i = j; continue
    i += 1

body = '\n'.join(out_lines) + '\n'

# ---------------------------------------------------------------- diff report
rep = []
rep.append('# Appendix B \u2014 regenerated test vectors: what changed\n')
rep.append('Source of the new numbers: the algorithms as shipped in the NGCC submission')
rep.append('(`FEILIAN.zip`, Reference 512/768/1024), instrumented only to dump the')
rep.append('intermediate states.  Nothing in the algorithm was altered.\n')
rep.append('For every section the counter `t` is the **true cumulative message length**:')
rep.append('`t = min(1024\u00b7(i+1), \u2016M\u2016)`, i.e. the tweak of the final block excludes the padding.\n')
rep.append('Sections changed: **%d**\n' % len(changes))
rep.append('| variant | example | block | section | words changed | old (as printed) | new (correct) |')
rep.append('|---|---|---|---|---|---|---|')
for c in changes:
    n = sum(1 for x, y in zip(c['old'], c['new']) if x != y)
    rep.append('| FEILIAN-%s | %s | %d | %s | %d/%d | `%s \u2026` | `%s \u2026` |'
               % (c['variant'], 'abc (24-bit)' if c['example'] == 'abc' else 'a\u00d7129 (1032-bit)',
                  c['block'], c['section'].rstrip(':'), n, len(c['old']),
                  c['old'][0], c['new'][0]))
rep.append('')
rep.append('Full values, section by section:\n')
for c in changes:
    rep.append('**FEILIAN-%s, %s, block %d, %s**\n'
               % (c['variant'], 'abc (24-bit)' if c['example'] == 'abc' else 'a\u00d7129 (1032-bit)',
                  c['block'], c['section'].rstrip(':')))
    rep.append('```')
    for k in range(0, len(c['old']), 4):
        rep.append('old  ' + ' '.join(c['old'][k:k + 4]))
    for k in range(0, len(c['new']), 4):
        rep.append('new  ' + ' '.join(c['new'][k:k + 4]))
    rep.append('```\n')

report = '\n'.join(rep)

(OUTDIR / 'AppendixB_test_vectors_revised.md').write_text(
    '# Appendix B \u2014 Test Vectors (regenerated)\n\n'
    '> Numbers below are produced by the NGCC submission implementation with the\n'
    '> counter convention of \u00a72.3 (true cumulative message length; the padding is\n'
    '> excluded from the final block\u2019s tweak).  Sections that differ from the\n'
    '> previously printed appendix are listed in `AppendixB_revision_diff.md`.\n\n'
    '```\n' + body + '```\n', encoding='utf-8')

(OUTDIR / 'AppendixB_test_vectors_revised.txt').write_text(body, encoding='utf-8')

(OUTDIR / 'AppendixB_revision_diff.md').write_text(report, encoding='utf-8')
print('changed sections:', len(changes))
for c in changes:
    print('  %s %s blk%d %s' % (c['variant'], c['example'], c['block'], c['section']))
print('written:', OUTDIR / 'AppendixB_test_vectors_revised.md')
print('written:', OUTDIR / 'AppendixB_revision_diff.md')
