import pathlib
OUT = pathlib.Path('.')
OLD = '''        if (i == num_blocks - 1) {
            block_bits = msg_bits - i * BLOCK_BITS;
        }
'''
for bits in ('512', '768', '1024'):
    s = pathlib.Path('trace_%s.c' % bits).read_text(encoding='utf-8')
    if OLD not in s:
        raise SystemExit('anchor missing for ' + bits)
    s = s.replace(OLD, '', 1)
    pathlib.Path('trace_pad_%s.c' % bits).write_text(s, encoding='utf-8')
    d = pathlib.Path('drv_%s.c' % bits).read_text(encoding='utf-8')
    d = d.replace('trace_%s.c' % bits, 'trace_pad_%s.c' % bits)
    pathlib.Path('drv_pad_%s.c' % bits).write_text(d, encoding='utf-8')
    print('padded variants written for', bits)
