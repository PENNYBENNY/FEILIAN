# -*- coding: utf-8 -*-
r"""Extract the numbers from the generated .tex files and compare them, word by
word, with AppendixB_test_vectors_revised.txt (and report the delta vs the
printed values recorded in AppendixB_revision_diff.md)."""
import io
import os
import re

BASE = r'C:\Users\NETSCAPE\Desktop\FEILIEN.version\260928'
SRC = os.path.join(BASE, 'AppendixB_test_vectors_revised.txt')
DIFF = os.path.join(BASE, 'AppendixB_revision_diff.md')
TEX_FULL = os.path.join(BASE, 'AppendixB_revised.tex')
TEX_TWO = os.path.join(BASE, 'AppendixB_revised_768_512.tex')

DATA_LINE = re.compile(r'^[0-9a-f]{16}( [0-9a-f]{16}){3}$')
WORD = re.compile(r'\\texttt\{([0-9a-f]{16})\}')
VARIANT = {'FEILIAN-1024': '1024', 'FEILIAN-768': '768', 'FEILIAN-512': '512'}
MARKERS = [(m, b) for b, m, _n in [('1024', 'B.1FEILIAN-1024', 16),
                                   ('768', 'B.2FEILIAN-768', 12),
                                   ('512', 'B.3FEILIAN-512', 8)]]


def txt_sections():
    sections, cur, words = {}, None, []
    for line in io.open(SRC, encoding='utf-8'):
        s = line.strip()
        if DATA_LINE.match(s):
            if cur is None:
                continue
            words += s.split()
            continue
        if words:
            sections[cur].append(words)
            words = []
        for marker, bits in MARKERS:
            if s == marker:
                cur = bits
                sections[cur] = []
                break
    if words:
        sections[cur].append(words)
    return sections


def tex_blocks(path):
    """-> {variant: [ [words] , ... ]} in document order, plus structural audit."""
    out, cur, words = {}, None, []
    n_row, n_tab, n_center = 0, 0, 0
    for line in io.open(path, encoding='utf-8'):
        s = line.strip()
        if s.startswith('\\subsection{'):
            if words:
                out[cur].append(words)
                words = []
            cur = VARIANT[s[len('\\subsection{'):-1]]
            out[cur] = []
            continue
        if s == '\\begin{tabular}{cccc}':
            n_tab += 1
        if s.startswith('\\end{tabular}'):
            if words:
                out[cur].append(words)
                words = []
        if s == '\\end{center}':
            n_center += 1
        if s.startswith('\\subsection') or not s:
            continue
        ws = WORD.findall(s)
        if ws:
            words += ws
            n_row += 1
    if words:
        out[cur].append(words)
    return out, n_row, n_tab, n_center


def old_values():
    """-> {(bits, 'abc'|'a129', block, section): [old words]}"""
    head = re.compile(r'^\*\*(FEILIAN-(\d+)), (abc|a\u00d7129) \((\d+)-bit\), block (\d+), (.+)\*\*$')
    res, text, i = {}, io.open(DIFF, encoding='utf-8').read().split('\n'), 0
    while i < len(text):
        m = head.match(text[i].strip())
        if not m:
            i += 1
            continue
        key = (m.group(2), 'abc' if m.group(3) == 'abc' else 'a129', int(m.group(5)),
               m.group(6).strip())
        rows = []
        while i < len(text) and not text[i].startswith('```'):
            i += 1
        i += 1
        while i < len(text) and not text[i].startswith('```'):
            if text[i].strip().startswith('old '):
                rows.append(text[i].strip()[4:].split())
            i += 1
        res[key] = [w for r in rows for w in r]
        i += 1
    return res


OFF = {'State v after 1 round': 4, 'State v after 2 rounds': 5,
       'State v after 5 rounds': 6, 'State v after 10 rounds': 7,
       'State v after 20 rounds': 8, 'Hash digest output': 9}


def main():
    txt = txt_sections()
    tex_full, nr, ntab, nc = tex_blocks(TEX_FULL)
    tex_two, nr2, ntab2, nc2 = tex_blocks(TEX_TWO)

    print('=== tex structure ===')
    print('%s : %d data rows, %d tabulars, %d center envs' % (os.path.basename(TEX_FULL), nr, ntab, nc))
    print('%s : %d data rows, %d tabulars, %d center envs' % (os.path.basename(TEX_TWO), nr2, ntab2, nc2))
    print('  tabulars == center envs (every tabular is centred): %s / %s'
          % (ntab == nc, ntab2 == nc2))

    ok = True
    for bits in ('1024', '768', '512'):
        a, b = txt[bits], tex_full[bits]
        same = (len(a) == len(b)) and all(x == y for x, y in zip(a, b))
        ok &= same
        print('full  FEILIAN-%s: %d txt blocks vs %d tex blocks -> %s'
              % (bits, len(a), len(b), 'IDENTICAL' if same else 'MISMATCH'))
        if not same:
            for k, (x, y) in enumerate(zip(a, b)):
                if x != y:
                    print('   block %d differs: %s != %s' % (k, x[:2], y[:2]))

    for bits in ('768', '512'):
        a, b = txt[bits], tex_two[bits]
        same = (len(a) == len(b)) and all(x == y for x, y in zip(a, b))
        ok &= same
        print('2-sec FEILIAN-%s: %d txt blocks vs %d tex blocks -> %s'
              % (bits, len(a), len(b), 'IDENTICAL' if same else 'MISMATCH'))

    # every 'old' value must be absent from the new document (they are superseded)
    olds = old_values()
    flat = {bits: [w for blk in tex_full[bits] for w in blk] for bits in ('768', '512', '1024')}
    stale = 0
    for (bits, msg, blk, sec), ow in olds.items():
        if sec not in OFF:
            continue
        want = txt[bits][OFF[sec]] if msg == 'abc' else txt[bits][
            (21 if blk == 1 else 14) + (OFF[sec] - 4)]
        assert want == ow or any(x != y for x, y in zip(want, ow)), 'no change recorded'
        # the superseded words must no longer appear in that slot
        if all(w in flat[bits] for w in ow) and want == ow:
            stale += 1
    print('=== digest / round-section deltas vs printed values ===')
    for (bits, msg, blk, sec), ow in sorted(olds.items()):
        want = txt[bits][OFF[sec]] if msg == 'abc' else txt[bits][
            (21 if blk == 1 else 14) + (OFF[sec] - 4)]
        ch = sum(1 for x, y in zip(ow, want) if x != y)
        print('  %-4s %-5s blk%d %-22s changed words: %2d/%d  %s -> %s'
              % (bits, msg, blk, sec, ch, len(want), ow[0], want[0]))

    print()
    print('RESULT:', 'ALL CHECKS PASSED' if ok else 'FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
