import re, pathlib

SPEC = pathlib.Path('C:/Users/NETSCAPE/AppData/Local/Temp/feilian_spec/appendixB_printed.txt')
REV = pathlib.Path('C:/Users/NETSCAPE/Desktop/FEILIEN.version/260928/AppendixB_test_vectors_revised.txt')

raw = SPEC.read_text(encoding='utf-8').splitlines()
printed = []
for l in raw:
    s = l.strip()
    if not s or (s.startswith('===') and 'PAGE' in s) or re.fullmatch(r'\d{1,3}', s):
        continue
    printed.append(s)
revised = [l.rstrip() for l in REV.read_text(encoding='utf-8').splitlines() if l.strip()]

print('printed lines :', len(printed))
print('revised lines :', len(revised))
if len(printed) != len(revised):
    print('  !! line counts differ')

HEX4 = re.compile(r'^[0-9a-f]{16}$')
LABEL = re.compile(r'^(IV:|Constants:|Round constants:|Message block after padding:|'
                   r'First compressionMessage block after padding:|'
                   r'Second compressionMessage block after padding:|'
                   r'Initial state of v:|State v after \d+ rounds?:|Hash digest output:)')

cur = None           # current section label
diffs = {}
for idx, (a, b) in enumerate(zip(printed, revised)):
    if LABEL.match(b):
        cur = b
    if a != b:
        diffs.setdefault(cur, []).append((idx, a, b))

print()
print('overall differing lines:', sum(len(v) for v in diffs.values()))
print()
for k in diffs:
    print('  section:', k)

print()
allowed = set()
for v in ('768', '512'):
    for ex in ('abc', 'a_times_129'):
        for sec in ['State v after 1 round:', 'State v after 2 rounds:', 'State v after 5 rounds:',
                    'State v after 10 rounds:', 'State v after 20 rounds:', 'Hash digest output:']:
            allowed.add(sec)
unexpected = [k for k in diffs if k not in allowed]
print('sections changed that were NOT expected:', unexpected if unexpected else 'none')

# final consistency: 1024 must be untouched
c1024 = [k for k in diffs if k and '1024' in '']
print()
print('sample diffs (first 6 lines of two sections):')
for k, v in list(diffs.items())[:2]:
    print('--', k)
    for idx, a, b in v[:6]:
        print('   -', a)
        print('   +', b)
