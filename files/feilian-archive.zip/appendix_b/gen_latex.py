# -*- coding: utf-8 -*-
r"""
Regenerate Appendix B as LaTeX (same layout as the submitted appendix)
using the corrected numbers in AppendixB_test_vectors_revised.txt.

Only numbers are substituted; the LaTeX scaffolding is reproduced from the
submitted appendix (\subsection / \textbf headers, tabular blocks, blank-line
placement, \texttt{} per 64-bit word).

Outputs:
  AppendixB_revised.tex            B.1 1024 + B.2 768 + B.3 512  (full appendix)
  AppendixB_revised_768_512.tex    B.2 768 + B.3 512 only (the sections that changed)
"""
import io
import os
import re

BASE = r'C:\Users\NETSCAPE\Desktop\FEILIEN.version\260928'
SRC = os.path.join(BASE, 'AppendixB_test_vectors_revised.txt')
DIFF = os.path.join(BASE, 'AppendixB_revision_diff.md')
OUT_FULL = os.path.join(BASE, 'AppendixB_revised.tex')
OUT_TWO = os.path.join(BASE, 'AppendixB_revised_768_512.tex')

DATA_LINE = re.compile(r'^[0-9a-f]{16}( [0-9a-f]{16}){3}$')

VARIANTS = [('1024', 'B.1FEILIAN-1024', 16),
            ('768', 'B.2FEILIAN-768', 12),
            ('512', 'B.3FEILIAN-512', 8)]
NHASH = {b: n for b, _m, n in VARIANTS}
MARKERS = [(m, b) for b, m, _n in VARIANTS]
STEPS = [1, 2, 5, 10, 20]


# --------------------------------------------------------------------------
# 1. parse the corrected appendix text into per-variant ordered blocks
# --------------------------------------------------------------------------
def parse(path):
    sections, cur, words = {}, None, []
    for line in io.open(path, encoding='utf-8'):
        s = line.strip()
        if DATA_LINE.match(s):
            if cur is None:          # the explanatory example at the top
                continue
            words += s.split()
            continue
        if words:
            sections[cur].append(words)
            words = []
        for marker, bits in MARKERS:
            if s == marker:
                cur = bits
                sections[cur] = []
                break
    if words:
        sections[cur].append(words)
    return sections


def check_layout(bits, blocks):
    """Validate the block geometry the LaTeX template relies on."""
    nh = NHASH[bits]
    want = [16, 4, 16, 16] + [16] * 5 + [nh]           # one-block: 10 blocks
    want += [16, 4, 16, 16] + [16] * 5                 # two-block, first compression
    want += [16, 16] + [16] * 5 + [nh]                 # second compression + digest
    got = [len(b) for b in blocks]
    assert got == want, '%s layout mismatch\n got %s\nwant %s' % (bits, got, want)


# --------------------------------------------------------------------------
# 2. LaTeX emitters
# --------------------------------------------------------------------------
def row(words):
    return '        ' + ' & '.join(r'\texttt{%s}' % w for w in words) + r' \\'


def tabular(words):
    out = ['\\begin{center}', '    \\begin{tabular}{cccc}']
    for i in range(0, len(words), 4):
        out.append(row(words[i:i + 4]))
    out.append('    \\end{tabular}')
    out.append('\\end{center}')
    return out


def message_tabular(words):
    out = ['\\begin{center}', '    \\begin{tabular}{cccc}', '    ']
    for i in range(0, len(words), 4):
        out.append(row(words[i:i + 4]))
    out.append('    ')
    out.append('    \\end{tabular}\\\\')
    out.append('\\end{center}')
    return out


def emit(bits, blocks):
    check_layout(bits, blocks)
    o = []
    o.append('\\subsection{FEILIAN-%s}' % bits)
    o.append('')

    def states(base):
        for k, st in enumerate(STEPS):
            o.append('State v after %d round%s:' % (st, '' if st == 1 else 's'))
            o.extend(tabular(blocks[base + k]))
            o.append('')

    # ---------------- one-block message ----------------
    o.append(r"\textbf{One-block message: ``abc''(24-bit)}\\")
    o.append('')
    o.append('')
    o.append('IV:')
    o.extend(tabular(blocks[0]))
    o.append('')
    o.append('Round constants:')
    o.extend(tabular(blocks[1]))
    o.append('')
    o.append('Message block after padding:')
    o.extend(message_tabular(blocks[2]))
    o.append('Initial state of v:')
    o.extend(tabular(blocks[3]))
    o.append('')
    states(4)
    o.append('Hash value output:')
    o.extend(tabular(blocks[9]))
    o.append('')

    # ---------------- two-block message ----------------
    o.append(r"\textbf{Two-block message: ``aaa$\cdots$aaa''(1032-bit)}\\")
    o.append('')
    o.append('IV:')
    o.extend(tabular(blocks[10]))
    o.append('')
    o.append('Round constants:')
    o.extend(tabular(blocks[11]))
    o.append('')
    o.append(r'\textbf{First compression} Message block after padding:')
    o.extend(message_tabular(blocks[12]))
    o.append('')
    o.append('')
    o.append('Initial state of v:')
    o.extend(tabular(blocks[13]))
    o.append('')
    states(14)
    o.append(r'\textbf{Second compression} Message block after padding:')
    o.extend(message_tabular(blocks[19]))
    o.append('')
    o.append('Initial state of v:')
    o.extend(tabular(blocks[20]))
    o.append('')
    states(21)
    o.append('Hash value output:')
    o.extend(tabular(blocks[26]))
    o.append('')
    return o


# --------------------------------------------------------------------------
# 3. cross-check against the independently produced old->new diff
# --------------------------------------------------------------------------
DIFF_HEAD = re.compile(r'^\*\*(FEILIAN-(\d+)), (abc|a\u00d7129) \((\d+)-bit\), block (\d+), (.+)\*\*$')
SEC_IDX = {'State v after 1 round': 0, 'State v after 2 rounds': 1,
           'State v after 5 rounds': 2, 'State v after 10 rounds': 3,
           'State v after 20 rounds': 4, 'Hash digest output': 5}
OFF_ONE = [4, 5, 6, 7, 8, 9]
OFF_BLK1 = [21, 22, 23, 24, 25, 26]


def spot_check(sections):
    text = io.open(DIFF, encoding='utf-8').read().split('\n')
    checked, i = 0, 0
    while i < len(text):
        m = DIFF_HEAD.match(text[i].strip())
        if not m:
            i += 1
            continue
        bits, msg, blk, sec = m.group(2), m.group(3), int(m.group(5)), m.group(6).strip()
        new_rows = []
        while i < len(text) and not text[i].startswith('```'):
            i += 1
        i += 1
        while i < len(text) and not text[i].startswith('```'):
            line = text[i].strip()
            if line.startswith('new '):
                new_rows.append(line[4:].split())
            i += 1
        new_words = [w for r in new_rows for w in r]
        offs = OFF_ONE if msg == 'abc' else OFF_BLK1
        got = sections[bits][offs[SEC_IDX[sec]]]
        assert got == new_words, 'mismatch: %s %s %s' % (bits, msg, sec)
        checked += 1
        i += 1
    return checked


# --------------------------------------------------------------------------
def main():
    sections = parse(SRC)

    IV = ('243f6a8885a308d3 452821e638d01377 9216d5d98979fb1b ba7c9045f12c7f99 '
          '13198a2e03707344 be5466cf34e90c6c d1310ba698dfb5ac 24a19947b3916cf7 '
          'a4093822299f31d0 c0ac29b7c97c50dd 2ffd72dbd01adfb7 0801f2e2858efc16 '
          '082efa98ec4e6c89 3f84d5b5b5470917 b8e1afed6a267e96 636920d871574e69').split()
    RC = '6a09e667f3bcc908 bb67ae8584caa73b 3c6ef372fe94f82b a54ff53a5f1d36f1'.split()
    for bits, _m, _n in VARIANTS:
        b = sections[bits]
        check_layout(bits, b)
        assert b[0] == IV and b[10] == IV and b[3] == IV and b[13] == IV, 'IV drift'
        assert b[1] == RC and b[11] == RC, 'RC drift'
        assert b[2][0] == '6162630000000000' and b[2][1:] == ['0' * 16] * 15, 'abc pad'
        assert set(b[12]) == {'6161616161616161'}, 'a-pad block0'
        assert b[19][0] == '6100000000000000' and b[19][1:] == ['0' * 16] * 15, 'a-pad block1'

    digests = {('768', 0): 'ea0a78e8fd68db09', ('768', 1): '5fc94695955a87e9',
               ('512', 0): 'fc7320c565f60ec6', ('512', 1): 'a2189955d155788c',
               ('1024', 0): '0507e4b1ef75d025', ('1024', 1): 'e3383d3260ea32ed'}
    for (bits, case), head in digests.items():
        got = sections[bits][9] if case == 0 else sections[bits][26]
        assert got[0] == head, 'digest drift %s %s: %s' % (bits, case, got[0])

    print('diff cross-check: %d sections verified' % spot_check(sections))

    full, two = [], []
    for bits, _m, _n in VARIANTS:
        full.extend(emit(bits, sections[bits]))
    for bits in ('768', '512'):
        two.extend(emit(bits, sections[bits]))

    io.open(OUT_FULL, 'w', encoding='utf-8', newline='\n').write('\n'.join(full) + '\n')
    io.open(OUT_TWO, 'w', encoding='utf-8', newline='\n').write('\n'.join(two) + '\n')
    print('written: %s (%d lines)' % (OUT_FULL, len(full)))
    print('written: %s (%d lines)' % (OUT_TWO, len(two)))


if __name__ == '__main__':
    main()
