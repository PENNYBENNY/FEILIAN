import pathlib

BASE = pathlib.Path('C:/Users/NETSCAPE/AppData/Local/Temp/feilian_sub/FEILIAN/Implementations/Reference_Implementation')
OUT  = pathlib.Path('C:/Users/NETSCAPE/AppData/Local/Temp/feilian_appb_gen')
OUT.mkdir(parents=True, exist_ok=True)

ANCHOR_COMPRESS = 'static void feilian_compress(uint64_t h_out[MATRIX_ROWS][MATRIX_COLS],'

TRACE_DECL = '''/* ===== temporary trace instrumentation (Appendix B regeneration) ===== */
#define TRACE_MAX_BLOCKS 8
#define TRACE_ROUNDS     21
typedef struct {
    uint64_t domain[MATRIX_COLS];
    uint64_t initial[MATRIX_ROWS][MATRIX_COLS];
    uint64_t after[TRACE_ROUNDS][MATRIX_ROWS][MATRIX_COLS];
    uint64_t final[MATRIX_ROWS][MATRIX_COLS];
} feilian_trace_block_t;
static feilian_trace_block_t g_trace[TRACE_MAX_BLOCKS];
static int g_trace_on = 0;
static int g_trace_count = 0;
static int g_trace_cur = -1;
void FeilianTraceOn(void) { g_trace_on = 1; g_trace_count = 0; g_trace_cur = -1; }
int  FeilianTraceCount(void) { return g_trace_count > TRACE_MAX_BLOCKS ? TRACE_MAX_BLOCKS : g_trace_count; }
/* ===================================================================== */

'''

A2_OLD = '''    uint64_t h_initial[MATRIX_ROWS][MATRIX_COLS];
    copy_state(h_initial, h_in);
    copy_state(h_out, h_in);
'''
A2_NEW = '''    uint64_t h_initial[MATRIX_ROWS][MATRIX_COLS];
    copy_state(h_initial, h_in);
    copy_state(h_out, h_in);
    if (g_trace_on) {
        g_trace_cur = g_trace_count++;
        if (g_trace_cur < TRACE_MAX_BLOCKS) {
            memcpy(g_trace[g_trace_cur].domain, flag_and_bits, sizeof(flag_and_bits));
            copy_state(g_trace[g_trace_cur].initial, h_in);
        }
    }
'''

A3_OLD = '''        } else {
            round_without_msg(h_out, rc, flag_and_bits);
        }
    }
'''
A3_NEW = '''        } else {
            round_without_msg(h_out, rc, flag_and_bits);
        }
        if (g_trace_on && g_trace_cur >= 0 && g_trace_cur < TRACE_MAX_BLOCKS) {
            copy_state(g_trace[g_trace_cur].after[rnd + 1], h_out);
        }
    }
'''

A4_OLD = '    add_state(h_out, h_initial);'
A4_NEW = '''    if (g_trace_on && g_trace_cur >= 0 && g_trace_cur < TRACE_MAX_BLOCKS) {
        copy_state(g_trace[g_trace_cur].final, h_out);
    }
    add_state(h_out, h_initial);'''

DRIVER = r'''#include <stdio.h>
#include <string.h>

#include "trace_%BITS%.c"

static void dump_state(const char *label, const uint64_t s[MATRIX_ROWS][MATRIX_COLS])
{
    printf("%s\n", label);
    for (int r = 0; r < MATRIX_ROWS; r++) {
        for (int c = 0; c < MATRIX_COLS; c++) {
            printf("%016llx", (unsigned long long)s[r][c]);
            printf("%c", c == MATRIX_COLS - 1 ? '\n' : ' ');
        }
    }
}

static void run(const char *name, const unsigned char *msg, unsigned long long bits)
{
    unsigned char digest[HASH_BYTES];
    memset(digest, 0, sizeof(digest));
    FeilianTraceOn();
    int rc = CryptHash(DRV_DIGEST_BITS, msg, bits, digest);
    printf("MSG %s %llu rc=%d blocks=%d\n", name, bits, rc, FeilianTraceCount());
    if (rc != 0) return;
    for (int i = 0; i < FeilianTraceCount(); i++) {
        const feilian_trace_block_t *b = &g_trace[i];
        printf("BLOCK %d\n", i);
        printf("DOMAIN %016llx %016llx %016llx %016llx\n",
               (unsigned long long)b->domain[0], (unsigned long long)b->domain[1],
               (unsigned long long)b->domain[2], (unsigned long long)b->domain[3]);
        dump_state("INIT", b->initial);
        for (int r = 1; r <= TOTAL_ROUNDS; r++) {
            char lab[32];
            snprintf(lab, sizeof(lab), "ROUND %d", r);
            dump_state(lab, b->after[r]);
        }
        dump_state("FINAL", b->final);
    }
    printf("DIGEST ");
    for (int i = 0; i < HASH_BYTES; i++) printf("%02x", digest[i]);
    printf("\nEND\n");
}

int main(void)
{
    unsigned char m1[3];
    static unsigned char m2[129];
    m1[0] = 'a'; m1[1] = 'b'; m1[2] = 'c';
    memset(m2, 'a', sizeof(m2));
    run("abc", m1, 24ULL);
    run("a_times_129", m2, 1032ULL);
    return 0;
}
'''

for bits in ('512', '768', '1024'):
    src = (BASE / ('FEILIAN' + bits) / 'CryptHash_AlgorithmInstance.c').read_text(encoding='utf-8')
    for old, new, tag in ((ANCHOR_COMPRESS, TRACE_DECL + ANCHOR_COMPRESS, 'compress'),
                          (A2_OLD, A2_NEW, 'initial'),
                          (A3_OLD, A3_NEW, 'rounds'),
                          (A4_OLD, A4_NEW, 'final')):
        if old not in src:
            raise SystemExit('anchor %s not found for %s' % (tag, bits))
        src = src.replace(old, new, 1)
    (OUT / ('trace_%s.c' % bits)).write_text(src, encoding='utf-8')
    drv = DRIVER.replace('%BITS%', bits)
    drv = '#define DRV_DIGEST_BITS ' + bits + '\n' + drv
    (OUT / ('drv_%s.c' % bits)).write_text(drv, encoding='utf-8')
    print('generated trace_%s.c + drv_%s.c' % (bits, bits))
