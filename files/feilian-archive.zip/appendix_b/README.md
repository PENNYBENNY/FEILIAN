# Appendix B — regeneration pipeline

Reproduces `AppendixB_test_vectors_revised.txt` / `.md` from source, and re-runs the
checks that show the original appendix mixed two counter conventions.

Nothing here is part of the submission. The algorithm files are never edited: the
scripts copy them into a working directory and add a read-only trace probe that dumps
the state after each round.

## Inputs

| what | default path used by the scripts |
|---|---|
| NGCC submission package, unpacked (`FEILIAN.zip`) | `%TEMP%\feilian_sub\FEILIAN\Implementations\Reference_Implementation` |
| Specification PDF, already converted to `appendixB_printed.txt` | `%TEMP%\feilian_spec` |
| output directory (the specification working folder) | `C:\Users\NETSCAPE\Desktop\FEILIEN.version\260928` |

Every script carries these paths as constants near the top (`BASE` / `SPEC` / `OUT` /
`OUTDIR`); edit them for another machine. Scripts 2-5 must be run **from the working
directory** that holds the generated `trace_*.txt` files, because they open them by
relative name.

To rebuild `appendixB_printed.txt` from the PDF:

```python
from pypdf import PdfReader
r = PdfReader('hash-10-spec.pdf')
open('appendixB_printed.txt', 'w', encoding='utf-8').write('\n'.join(
    '=' * 30 + ' PAGE %d ' % (i + 1) + '=' * 30 + '\n' + (p.extract_text() or '')
    for i, p in enumerate(r.pages[53:68])))
```

## Steps

1. **`make_trace.py`** — copies Reference 512/768/1024, injects the trace probe into
   `feilian_compress`, writes `trace_<bits>.c` and `drv_<bits>.c`.
   Build and run each driver in the working directory:

   ```
   gcc -O1 -std=c99 -I<ref-dir>/FEILIAN<bits> drv_<bits>.c -o tr_<bits>.exe
   ./tr_<bits>.exe > trace_<bits>.txt
   ```

   Each `trace_<bits>.txt` holds, per compression: the tweak words, the input state,
   the state after rounds 1, 2, 5, 10, 20, the final state, and the digest.

2. **`mkpad.py`** — removes the `block_bits = msg_bits - i*BLOCK_BITS` line (the
   *only* difference from step 1) and writes `trace_pad_<bits>.c` / `drv_pad_<bits>.c`.
   Build and run them the same way to get `trace_pad_<bits>.txt`: the counter
   convention the original appendix used for the 512- and 768-bit examples.

3. **`parse_printed.py`** — strips page numbers from `appendixB_printed.txt` and writes
   `printed_sections.json`.

4. **`verify.py`** — the checks. Expected output:

   - 1024: 20/20 sections equal to the printed appendix, 0 unexpected mismatches.
   - 768 / 512: 8 sections equal (all of block 0 plus both `Initial state of v`),
     12 expected mismatches (everything that depends on the final block's counter).
   - padded-counter build: 768 and 512 reproduce **17/17** printed sections;
     1024 reproduces only 5.

5. **`gen_appendix.py`** — rebuilds every section in the printed layout (same labels,
   same line breaks, counter = true cumulative message length) and writes the revised
   appendix plus the old→new diff.

6. **`diffcheck.py`** — line-by-line comparison of the revised appendix against the
   printed one. Confirms exactly 405 = 405 lines, 78 changed lines, and that every
   changed line falls in one of the six sections that depend on the final counter
   (76 of them in FEILIAN-768 and FEILIAN-512; B.1 FEILIAN-1024 is byte-identical).

7. **`gen_latex.py`** — re-emits the revised appendix as LaTeX in the submitted
   appendix's own layout (`\subsection` / `\textbf` headers, one `center` + `tabular`
   per block, `\texttt{}` per 64-bit word, 8-space row indent, the blank lines the
   original uses around the message-block tabulars). Only numbers are substituted;
   the scaffolding is copied from the submitted `.tex`.

   Inputs `AppendixB_test_vectors_revised.txt` and cross-checks every corrected
   section against `AppendixB_revision_diff.md` (24/24 must agree). Writes:

   | output | content |
   |---|---|
   | `AppendixB_revised.tex` | B.1 1024 + B.2 768 + B.3 512, 825 lines |
   | `AppendixB_revised_768_512.tex` | B.2 + B.3 only (the two changed sections), 548 lines |

   Both files contain 27 data blocks per variant: IV, round constants, message block,
   `Initial state of v`, the five round snapshots and the digest, for the one-block
   case; and the same for both compressions of the two-block case.

8. **`verify_latex.py`** — end-to-end check of the generated `.tex`: every number is
   extracted again and compared word by word with the revised appendix text, and the
   `old` values from the diff are re-listed with their per-word delta. Expected
   output: `1024/768/512 -> IDENTICAL`, `ALL CHECKS PASSED`.
