import json, pathlib, re

printed = {tuple(k.split('|')): v
           for k, v in json.loads(pathlib.Path('printed_sections.json').read_text(encoding='utf-8')).items()}


def parse_trace(p):
    out = {}
    cur = msg = blk = lab = None
    for line in pathlib.Path(p).read_text().splitlines():
        t = line.strip()
        if t.startswith('MSG '):
            msg = t.split()[1]; continue
        if t.startswith('BLOCK '):
            blk = int(t.split()[1]); cur = out.setdefault((msg, blk), {}); continue
        if t.startswith('DOMAIN '):
            cur['DOMAIN'] = t.split()[1:]; continue
        if t.startswith('DIGEST '):
            cur['DIGEST'] = t.split()[1]; continue
        if t in ('INIT', 'FINAL') or re.fullmatch(r'ROUND \d+', t):
            lab = t; cur[lab] = []; continue
        parts = t.split()
        if cur is not None and lab and len(parts) == 4 and all(re.fullmatch(r'[0-9a-f]{16}', x) for x in parts):
            cur[lab].extend(parts)
    return out


def transpose(w):
    m = [None] * 16
    for r in range(4):
        for c in range(4):
            m[c * 4 + r] = w[r * 4 + c]
    return m


def dig_words(h):
    return [h[i:i + 16] for i in range(0, len(h), 16)]


SECS = [('Initial state of v', 'INIT', 'either'),
        ('State v after 1 round', 'ROUND 1', None),
        ('State v after 2 rounds', 'ROUND 2', None),
        ('State v after 5 rounds', 'ROUND 5', None),
        ('State v after 10 rounds', 'ROUND 10', None),
        ('State v after 20 rounds', 'ROUND 20', None)]


def match_initial(w, pr):
    """The printed 'Initial state of v' block for the *first* compression is laid
    out transposed relative to the C matrix, the one for the second compression is
    not.  Both spellings are accepted here; this section is never recomputed."""
    return w == pr or transpose(w) == pr

LASTBLOCK = {('512', 'abc', 0), ('512', 'a_times_129', 1),
             ('768', 'abc', 0), ('768', 'a_times_129', 1)}

badall = []

print('### A. shipped code (true-length counter) vs printed Appendix B')
for variant in ('1024', '768', '512'):
    sub = {k: v for k, v in printed.items() if k[0] == variant}
    tr = parse_trace('trace_%s.txt' % variant)
    n_ok = n_ed = n_bad = 0
    for exname, exkey in (('abc', 'abc'), ('a_times_129', 'a129')):
        for blk in (0, 1):
            cfg = tr.get((exname, blk))
            if cfg is None:
                continue
            for secname, key, view in SECS:
                pr = sub.get((variant, exkey, str(blk), secname))
                if pr is None:
                    continue
                if view == 'either':
                    same = match_initial(cfg[key], pr)
                    exp_diff = False
                else:
                    got = view(cfg[key]) if view else cfg[key]
                    same = (got == pr)
                    exp_diff = (variant, exname, blk) in LASTBLOCK
                if same == exp_diff:
                    n_bad += 1
                    badall.append((variant, exname, blk, secname, 'matched' if same else 'mismatch'))
                elif same:
                    n_ok += 1
                else:
                    n_ed += 1
        dblk = 0 if exname == 'abc' else 1
        last = tr.get((exname, dblk))
        if last is not None and 'DIGEST' in last:
            pr = sub.get((variant, exkey, str(dblk), 'Hash digest output'))
            if pr is not None:
                same = (dig_words(last['DIGEST']) == pr)
                exp_diff = (variant, exname, dblk) in LASTBLOCK
                if same == exp_diff:
                    n_bad += 1
                    badall.append((variant, exname, dblk, 'digest', 'matched' if same else 'mismatch'))
                elif same:
                    n_ok += 1
                else:
                    n_ed += 1
    print('  variant %-4s : matches printed %2d   expected mismatch %2d   unexpected %d'
          % (variant, n_ok, n_ed, n_bad))

print()
print('### B. padded-length-counter build vs printed Appendix B')
for variant in ('1024', '768', '512'):
    sub = {k: v for k, v in printed.items() if k[0] == variant}
    tr = parse_trace('trace_pad_%s.txt' % variant)
    n_same = n_diff = 0
    for exname, exkey in (('abc', 'abc'), ('a_times_129', 'a129')):
        for blk in (0, 1):
            cfg = tr.get((exname, blk))
            if cfg is None:
                continue
            for secname, key, view in SECS:
                pr = sub.get((variant, exkey, str(blk), secname))
                if pr is None:
                    continue
                if view == 'either':
                    continue          # independent of t, always identical
                got = view(cfg[key]) if view else cfg[key]
                if got == pr:
                    n_same += 1
                else:
                    n_diff += 1
        dblk = 0 if exname == 'abc' else 1
        last = tr.get((exname, dblk))
        if last is not None and 'DIGEST' in last:
            pr = sub.get((variant, exkey, str(dblk), 'Hash digest output'))
            if pr is not None:
                if dig_words(last['DIGEST']) == pr:
                    n_same += 1
                else:
                    n_diff += 1
    print('  variant %-4s : same %2d   different %2d   %s'
          % (variant, n_same, n_diff, 'REPRODUCES printed values' if n_diff == 0 else ''))

print()
print('unexpected mismatches:', badall if badall else 'none')

print()
print('### C. counter t actually fed into each compression (shipped code)')
for variant in ('1024', '768', '512'):
    tr = parse_trace('trace_%s.txt' % variant)
    for exname in ('abc', 'a_times_129'):
        parts = []
        for blk in (0, 1):
            cfg = tr.get((exname, blk))
            if cfg is None:
                continue
            d = cfg['DOMAIN']
            t = (int(d[2], 16) << 64) | int(d[3], 16)
            parts.append('blk%d t=%d' % (blk, t))
        print('  %-4s %-12s %s' % (variant, exname, '; '.join(parts)))
