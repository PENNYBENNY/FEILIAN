# FEILIAN — 独立 Python 实现

`feilian.py` 是 FEILIAN-512 / 768 / 1024 的独立 Python 实现。它**不是**对提交 C 代码的移植，而是按规范从零重写的，用于：

- 独立复核官方 KAT
- 复核技术评估报告 v1.0.2 里 R2 那条具名实验
- 提供一个不依赖 C 工具链、可读、可审计的参考实现

结论先给：**对官方 KAT_2_12 的 12291 个向量全部逐字节复现（12291/12291，零失配）**，并且与编译运行的真实 C 实现输出一致。

---

## 1. 文件

| 文件 | 用途 |
|---|---|
| `feilian.py` | 实现本体（含 `__main__` 自检） |
| `validate_all.py` | **完整验证套件**，一条命令跑完 A–E 五组检查 |
| `kat_check.py` | 官方 KAT_2_12 全量比对（12291 向量） |
| `consistency.py` | 流式 vs 一次性一致性（含块边界） |
| `repro_abc.c` | C 侧驱动，链接未改动的提交包，用于交叉验证 |

运行（用隔离 venv，无第三方依赖）：

```bash
<venv>/python feilian.py           # 自检
<venv>/python validate_all.py      # 完整验证（约 30 秒）
```

---

## 2. 采用的约定

实现默认采用**提交的 C 实现与官方 KAT 实际使用的约定**：

| 项 | 取值 |
|---|---|
| 消息字节 → 64-bit 字 | 小端（规范 §3.2） |
| 计数器 `t` 累计口径 | **真实累计消息长度**——末块只计其真实位长，不计填充 |
| 计数器字序 | 高字在前（`t = t₀ ‖ t₁`，`t₀` 为高 64 位） |
| AddConstant | 轮常数 → row 1；tweak（version/flag/counter）→ row 3 |
| 摘要序列化 | 行优先，字内小端 |

**末字节掩码**：与提交的 C 实现**不同**，本实现会把 `msg_bits` 之后的位清零。这对应评估报告 R4(a)：C 代码的 `memcpy` 复制了整个末字节，未声明的位会进入压缩函数，使结果依赖调用方从未声明的比特。本实现不复制这个缺陷。

---

## 3. 两套约定是参数化的，不是硬编码

评估报告 R2 的核心指控是"规范第 2 章的字面读法与提交实现不一致"。这两处分歧被显式建模为 `Convention`：

```python
from feilian import feilian, Convention

feilian(b"abc", 1024).hex()
# 0507e4b1... —— 提交 C 实现的输出

feilian(b"abc", 1024, Convention.for_spec_chapter2()).hex()
# 8b27103d... —— 规范第 2 章字面约定的输出
```

| 轴 | 提交实现 | 规范第 2 章 |
|---|---|---|
| IV 第 7 字（row 1, col 3） | `0x3F84D5B5B5470917` | `0x3D84D5B5B5470917`（p.3 印刷值） |
| AddConstant 行序 | 常数 → row 1 | tweak → row 1（p.9 印刷值） |

另有 `final_block_counting="padded"` 可复现 Appendix B 512/768 例子所用的填充口径。

**默认值 = 提交实现的约定**，因为那是官方 KAT 钉死的口径。这两处分歧**不应被静默混合**。

---

## 4. 验证结果

`validate_all.py` 输出（实测）：

| 组 | 检查 | 结果 |
|---|---|---|
| A | 官方 KAT_2_12 × 3 变体（4097 长度） | **12291 / 12291 匹配，0 失配** |
| B | 与编译的提交 C 代码交叉验证（abc / 空 / 129×a） | 逐字节一致 |
| C | 报告 R2 具名实验的两侧数值 | `0507e4b1…` 与 `8b27103d…` 均复现 |
| D | 流式 == 一次性（0–300 全覆盖 + 511/512/513/1000/4096） | 909 例全通过 |
| E | 摘要只依赖所声明的位串（尾随位不影响） | 全通过 |

### 与报告数值的对照

| 来源 | FEILIAN-1024(abc) 前 16 字节 | 状态 |
|---|---|---|
| 报告称"C 侧" | `0507e4b1ef75d025dfa303ea0a8e2c47` | ✅ 用编译的 C 代码复现 |
| 报告称"第 2 章约定" | `8b27103d98eabd06b36a8a1d2148d8e6` | ✅ 用本实现 + `for_spec_chapter2()` 复现 |

报告表格的**两列都已独立复现**。

---

## 5. 未覆盖的部分，及原因

诚实划界——以下三组**没有**验证，不是遗漏而是不可为：

| 文件 | 为什么没验 |
|---|---|
| `KAT_2_23_*` / `KAT_2_33_*` | 记录里只有 `Msg_Seed`（种子）与 `Msg_Exp`（消息首 8 字节 + 末 8 字节的校验值），**没有完整消息**。重建消息需要实现 ICCS 的 DRNG（`drng.c`），那属于评估报告 R8 的共享测试基础设施，且提交 README 标注该文件**不可修改**。 |
| `KAT_Loop_*` | 记录里 `Msg` 是**完整的 8192-bit 消息**，但 `Dst` 是**一百万次链式迭代之后**的结果（见 `KAT_CryptHash.c` 第 612–622 行），不是对该消息直接求哈希。复现需要跑满百万次迭代。 |

两组都已在 `kat_check.py` 与 `kat_loop_check.py` 的注释中记录原因，避免后来者重复踩。

---

## 6. 复现方法

```bash
# 1. C 侧驱动（可选，仅用于交叉验证）
gcc -O2 -o repro_abc.exe repro_abc.c \
    "$TEMP/feilian_sub/FEILIAN/Implementations/Reference_Implementation/FEILIAN1024/CryptHash_AlgorithmInstance.c" \
    -I"$TEMP/feilian_sub/FEILIAN/Implementations/Reference_Implementation/FEILIAN1024"

# 2. 完整验证
python validate_all.py
```

依赖：Python 3.9+ 标准库；C 侧需要任意 C99 编译器。**基线是未改动的提交包** `%TEMP%\feilian_sub\FEILIAN`。

---

## 7. 已知边界

- **性能**：纯 Python、无优化，KAT 全量约 25 秒。不适合大数据量。
- **流式接口**：`FeilianStream` 保持 <256 字节缓冲，压缩已满的块，`digest()` 时才处理末块。`update_bits()` 支持任意位长输入，但内部按字节缓冲——代价是最后一个不满字节与之后的数据不能跨块共享（不影响正确性）。
- **计数器上限**：拒绝 `msg_bits >= 2**128`。
- **未做**：长消息 KAT（缺 DRNG）、百万次迭代回环、性能基准。
