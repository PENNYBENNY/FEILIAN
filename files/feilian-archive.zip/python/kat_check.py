"""Full official-KAT validation for the independent Python FEILIAN model.

Parses the official KAT_2_12_*.txt files supplied with the submission and
recomputes every vector with feilian.py, comparing the complete digest.

KAT file format (per record):
    Msg_Len = <bit length of the message>
    Msg     = <message bytes, hex; the final byte is bit-truncated>
    Dst_Len = <digest bit length>
    Dst     = <digest bytes, hex>

Note on the other KAT files in the same directory:
  KAT_2_23 / KAT_2_33 print only Msg_Seed plus a first/last-8-byte check
  value (Msg_Exp), so regenerating the message needs the ICCS DRNG.
  KAT_Loop prints the full message but its Dst is the result after
  1,000,000 chained iterations.  Neither is verifiable without that
  submission infrastructure, so this checker deliberately covers 2_12 only.
"""

import re
import sys
import time
from pathlib import Path

from feilian import feilian_from_bitstring, SUPPORTED_WIDTHS

VECTORS = Path(
    r"C:\Users\NETSCAPE\AppData\Local\Temp\feilian_sub\FEILIAN\Test_Vectors"
)

FILES = [
    ("KAT_2_12_FEILIAN512.txt", 512),
    ("KAT_2_12_FEILIAN768.txt", 768),
    ("KAT_2_12_FEILIAN1024.txt", 1024),
]


def parse(path: Path):
    """Yield (msg_bits, msg_bytes, dst_bits, dst_bytes) records."""
    text = path.read_text(encoding="utf-8", errors="replace")
    rec = {}

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(Msg_Len|Dst_Len)\s*=\s*(\d+)$", line)
        if m:
            rec[m.group(1)] = int(m.group(2))
            continue
        m = re.match(r"^(Msg|Dst)\s*=\s*([0-9A-Fa-f]*)$", line)
        if m:
            rec[m.group(1)] = bytes.fromhex(m.group(2))
            if m.group(1) == "Dst":
                need = {"Msg_Len", "Msg", "Dst_Len", "Dst"}
                if need <= rec.keys():
                    yield (rec["Msg_Len"], rec["Msg"],
                           rec["Dst_Len"], rec["Dst"])
                    rec = {}
                    continue
            continue

        raise SystemExit(f"unparsed line in {path.name}: {line!r}")


def main() -> int:
    total = mismatches = 0
    failures = []

    for fname, width in FILES:
        path = VECTORS / fname
        if not path.exists():
            print(f"  SKIP {fname} (not found)")
            continue

        n = ok = 0
        t0 = time.perf_counter()
        for msg_bits, msg, dst_bits, dst in parse(path):
            n += 1
            if dst_bits not in SUPPORTED_WIDTHS:
                failures.append((fname, msg_bits, "unsupported Dst_Len", ""))
                continue
            got = feilian_from_bitstring(msg, msg_bits, dst_bits)
            if got == dst:
                ok += 1
            else:
                mismatches += 1
                if len(failures) < 20:
                    failures.append(
                        (fname, msg_bits, got.hex()[:32], dst.hex()[:32]))
        dt = time.perf_counter() - t0
        total += n
        print(f"  {fname:32s} {ok}/{n} match   ({dt:.1f}s)")

    print()
    print(f"  TOTAL vectors : {total}")
    print(f"  mismatches    : {mismatches}")

    if failures:
        print("\n  first mismatches (file, msg_bits, got, expected):")
        for f in failures:
            print(f"    {f[0]} bits={f[1]} got={f[2]} exp={f[3]}")

    return 1 if mismatches else 0


if __name__ == "__main__":
    sys.exit(main())
