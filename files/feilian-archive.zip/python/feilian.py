"""
FEILIAN hash family - independent Python implementation.
FEILIAN 哈希族 —— 独立 Python 参考实现。

Implements FEILIAN-512 / FEILIAN-768 / FEILIAN-1024 per the submitted
specification, using the conventions that the supplied C implementations
and the official KAT material actually use:

  * little-endian message words        (spec section 3.2)
  * counter t accumulated as the TRUE cumulative message length,
    i.e. the final block contributes only its real bit length, not 1024
  * counter t placed high word first   (t = t0 || t1, t0 = high 64 bits)
  * constants XORed into row 1, tweak (version/flag/counter) into row 3
  * row-major digest serialisation with little-endian bytes within a word

Conventions that are deliberately parameterised (see `Convention`):

  * `iv_seventh_word`  - 0x3F... (implementations) or 0x3D... (spec p.3)
  * `constant_row`     - 1 (implementations) or 3 (spec p.9)

These two are the subject of assessment v1.0.2 finding R2.  The default
`Convention()` reproduces the supplied C implementations byte for byte;
`Convention.for_spec_chapter2()` reproduces the literal reading of the
specification text.  Do not silently mix the two.

Usage
-----
    from feilian import feilian, Convention

    feilian(b"abc", 1024).hex()
    feilian(b"abc", 512, convention=Convention.for_spec_chapter2()).hex()
    feilian_from_bitstring("abc", 19).hex()      # 19-bit prefix of "abc"

    # streaming
    with FeilianStream(1024) as h:
        h.update(b"abc")
        digest = h.digest()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

__all__ = [
    "feilian",
    "feilian_from_bitstring",
    "FeilianStream",
    "Convention",
    "DigestWidth",
    "DIGEST_512",
    "DIGEST_768",
    "DIGEST_1024",
    "SUPPORTED_WIDTHS",
    "FeilianError",
    "FeilianLengthError",
]

MASK64 = (1 << 64) - 1


class FeilianError(ValueError):
    """Raised for invalid inputs (bad width, over-long message, ...)."""


class FeilianLengthError(FeilianError):
    """Raised when a message exceeds the 128-bit counter domain."""


# --------------------------------------------------------------------------
#  Digest widths
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class DigestWidth:
    """Static parameters that differ between the three family members."""

    name: str
    digest_bits: int
    version: int          # public tweak word carrying the variant id
    hash_rows: int        # how many of the 4 state rows enter the digest

    @property
    def digest_bytes(self) -> int:
        return self.digest_bits // 8

    @property
    def digest_words(self) -> int:
        return self.digest_bits // 64


DIGEST_512 = DigestWidth(name="FEILIAN-512", digest_bits=512,
                         version=0x200, hash_rows=2)
DIGEST_768 = DigestWidth(name="FEILIAN-768", digest_bits=768,
                         version=0x300, hash_rows=3)
DIGEST_1024 = DigestWidth(name="FEILIAN-1024", digest_bits=1024,
                          version=0x400, hash_rows=4)

SUPPORTED_WIDTHS = {
    512: DIGEST_512,
    768: DIGEST_768,
    1024: DIGEST_1024,
}


# --------------------------------------------------------------------------
#  Convention bundle
# --------------------------------------------------------------------------

_IV_ROWS = (
    (0x243F6A8885A308D3, 0x13198A2E03707344,
     0xA4093822299F31D0, 0x082EFA98EC4E6C89),
    (0x452821E638D01377, 0xBE5466CF34E90C6C,
     0xC0AC29B7C97C50DD, 0x3F84D5B5B5470917),
    (0x9216D5D98979FB1B, 0xD1310BA698DFB5AC,
     0x2FFD72DBD01ADFB7, 0xB8E1AFED6A267E96),
    (0xBA7C9045F12C7F99, 0x24A19947B3916CF7,
     0x0801F2E2858EFC16, 0x636920D871574E69),
)


@dataclass(frozen=True)
class Convention:
    """Points where the specification text and the implementations diverge.

    Default values follow the supplied C implementations and the official
    KAT material.  `for_spec_chapter2()` follows the literal text of
    Chapter 2 (assessment v1.0.2, finding R2).
    """

    #: IV word at row 1, column 3.  0x3F... in every supplied implementation;
    #: 0x3D... as printed on specification p.3.
    iv_seventh_word: int = 0x3F84D5B5B5470917

    #: Row that receives the round constants.  1 in every supplied
    #: implementation; 3 as printed on specification p.9.
    constant_row: int = 1

    #: Counter word order.  "high-first" = t0 holds the high 64 bits,
    #: which is what the C code and the 2SC core do.
    counter_order: str = "high-first"

    #: What the last block contributes to the cumulative counter.
    #: "true"   - only its real message bit length (C / KAT convention)
    #: "padded" - a full 1024 bits (the 512/768 Appendix B examples)
    final_block_counting: str = "true"

    def __post_init__(self) -> None:
        if self.constant_row not in (1, 3):
            raise FeilianError("constant_row must be 1 or 3")
        if self.counter_order not in ("high-first", "low-first"):
            raise FeilianError("counter_order must be 'high-first' or 'low-first'")
        if self.final_block_counting not in ("true", "padded"):
            raise FeilianError(
                "final_block_counting must be 'true' or 'padded'")

    @classmethod
    def for_spec_chapter2(cls) -> "Convention":
        """The literal reading of specification Chapter 2 (pp. 3 and 9)."""
        return cls(iv_seventh_word=0x3D84D5B5B5470917, constant_row=3)

    def iv(self) -> tuple:
        rows = [list(r) for r in _IV_ROWS]
        rows[1][3] = self.iv_seventh_word
        return tuple(tuple(r) for r in rows)


# --------------------------------------------------------------------------
#  Round constants and Sigma maps
# --------------------------------------------------------------------------

_RC_0 = (0x6A09E667F3BCC908, 0xBB67AE8584CAA73B,
         0x3C6EF372FE94F82B, 0xA54FF53A5F1D36F1)

RC_GROUPS = tuple(
    tuple(_RC_0[(i + k) % 4] for k in range(4))
    for i in range(4)
)

# 20 rounds = 5 phases of 4 rounds; phase constants cycle RC1..RC4, RC1.
ROUND_CONSTANT_SCHEDULE = tuple(RC_GROUPS[i % 4] for i in range(5))


def _rotr64(x: int, n: int) -> int:
    n &= 63
    return ((x >> n) | (x << (64 - n))) & MASK64 if n else x


def _sigma0(x: int) -> int:
    return x ^ _rotr64(x, 5) ^ _rotr64(x, 48)


def _sigma1(x: int) -> int:
    return x ^ _rotr64(x, 11) ^ _rotr64(x, 40)


# --------------------------------------------------------------------------
#  Round layers
# --------------------------------------------------------------------------

def _sub_column(s: list, col: int) -> None:
    a, b, c, d = s[0][col], s[1][col], s[2][col], s[3][col]

    a = (a + b) & MASK64
    c = (c + d) & MASK64
    d ^= a
    d = _rotr64(d, 8)
    c = (c + _sigma0(d)) & MASK64
    b ^= c
    b = _rotr64(b, 63)
    a = (a + _sigma1(b)) & MASK64

    s[0][col], s[1][col], s[2][col], s[3][col] = a, b, c, d


def _sub_column_layer(s: list) -> None:
    for col in range(4):
        _sub_column(s, col)


def _shift_rows(s: list) -> None:
    row1, row2, row3 = s[1], s[2], s[3]
    row1[0], row1[1], row1[2], row1[3] = row1[1], row1[2], row1[3], row1[0]
    row2[0], row2[1], row2[2], row2[3] = row2[2], row2[3], row2[0], row2[1]
    row3[0], row3[1], row3[2], row3[3] = row3[3], row3[0], row3[1], row3[2]


def _add_constant(s: list, rc: tuple, tweak: list, constant_row: int) -> None:
    if constant_row == 1:
        rc_row, tweak_row = 1, 3
    else:
        rc_row, tweak_row = 3, 1
    tgt_rc, tgt_tw = s[rc_row], s[tweak_row]
    for c in range(4):
        tgt_rc[c] ^= rc[c]
        tgt_tw[c] ^= tweak[c]


# --------------------------------------------------------------------------
#  Compression function
# --------------------------------------------------------------------------

def _compress(h_in: list, words: list, is_last: bool, tweak_words: list,
              version: int, convention: Convention) -> list:
    tweak = [version, MASK64 if is_last else 0,
             tweak_words[0], tweak_words[1]]

    state = [row[:] for row in h_in]

    for rnd in range(20):
        rc = ROUND_CONSTANT_SCHEDULE[rnd // 4]
        if rnd % 4 == 0:
            # Message-bearing round: inject, one half-round, inject again,
            # then a second half-round before the constants go in.
            for c in range(4):
                state[0][c] ^= words[c]
                state[2][c] ^= words[4 + c]
            _sub_column_layer(state)
            _shift_rows(state)
            for c in range(4):
                state[0][c] ^= words[8 + c]
                state[2][c] ^= words[12 + c]
            _sub_column_layer(state)
            _shift_rows(state)
        else:
            # Message-free round: two half-rounds, then the constants.
            _sub_column_layer(state)
            _shift_rows(state)
            _sub_column_layer(state)
            _shift_rows(state)
        _add_constant(state, rc, tweak, convention.constant_row)

    for r in range(4):
        hr, sr = h_in[r], state[r]
        for c in range(4):
            sr[c] ^= hr[c]
    return state


# --------------------------------------------------------------------------
#  Message handling
# --------------------------------------------------------------------------

def _load_words(block: bytes) -> list:
    return [int.from_bytes(block[i * 8:i * 8 + 8], "little") for i in range(16)]


def _serialise(state: list, hash_rows: int) -> bytes:
    out = bytearray()
    for r in range(hash_rows):
        for c in range(4):
            out += state[r][c].to_bytes(8, "little")
    return bytes(out)


def _pad(msg: bytes, msg_bits: int) -> bytes:
    """Zero padding only, no in-block length field (per the specification)."""
    if msg_bits == 0:
        return bytes(128)

    msg_bytes = (msg_bits + 7) // 8
    rem = msg_bits % 1024
    pad_bits = 0 if rem == 0 else (1024 - rem)

    buf = bytearray(msg_bytes + (pad_bits + 7) // 8)
    buf[:msg_bytes] = msg[:msg_bytes]

    # Canonical final byte: anything past msg_bits must be zero.  The
    # supplied C code does NOT do this (assessment v1.0.2, finding R4);
    # we do, because otherwise the digest depends on bits the caller
    # never declared.
    if msg_bits % 8:
        buf[msg_bytes - 1] &= (0xFF << (8 - (msg_bits % 8))) & 0xFF

    return bytes(buf)


def _counter_words(total: int, order: str) -> list:
    if order == "high-first":
        return [(total >> 64) & MASK64, total & MASK64]
    return [total & MASK64, (total >> 64) & MASK64]


# --------------------------------------------------------------------------
#  Public one-shot API
# --------------------------------------------------------------------------

def feilian_from_bitstring(message, msg_bits: int, digest_bits: int = 1024,
                           convention: Optional[Convention] = None) -> bytes:
    """Hash the first `msg_bits` bits of `message`.

    `msg_bits` may be any non-negative integer, including values that are
    not multiples of 8.  Bits past `msg_bits` in the final byte are forced
    to zero, so the result depends only on the declared bit string.
    """
    if convention is None:
        convention = Convention()

    width = SUPPORTED_WIDTHS.get(digest_bits)
    if width is None:
        raise FeilianError(
            f"unsupported digest width {digest_bits}; "
            f"expected one of {sorted(SUPPORTED_WIDTHS)}")
    if msg_bits < 0:
        raise FeilianError("msg_bits must be non-negative")

    if isinstance(message, str):
        message = message.encode("utf-8")

    needed = (msg_bits + 7) // 8
    if len(message) < needed:
        raise FeilianError(
            f"message too short: need {needed} bytes for {msg_bits} bits, "
            f"got {len(message)}")
    if msg_bits >= (1 << 128):
        raise FeilianLengthError(
            "message length must fit the 128-bit counter (2**128 - 1 bits)")

    padded = _pad(message, msg_bits)
    num_blocks = len(padded) // 128

    state = [list(r) for r in convention.iv()]

    for i in range(num_blocks):
        if i == num_blocks - 1:
            if convention.final_block_counting == "true":
                block_bits = msg_bits - i * 1024
            else:
                block_bits = 1024
        else:
            block_bits = 1024

        total = (i + 1) * 1024 if convention.final_block_counting == "padded" \
            else min((i + 1) * 1024, msg_bits)

        tweak = _counter_words(total, convention.counter_order)
        words = _load_words(padded[i * 128:(i + 1) * 128])
        state = _compress(state, words, i == num_blocks - 1, tweak,
                          width.version, convention)

    return _serialise(state, width.hash_rows)


def feilian(message, digest_bits: int = 1024,
            convention: Optional[Convention] = None) -> bytes:
    """Hash a whole, byte-aligned message.  Returns the raw digest bytes."""
    if isinstance(message, str):
        message = message.encode("utf-8")
    return feilian_from_bitstring(message, len(message) * 8,
                                  digest_bits, convention)


def feilian_hex(message, digest_bits: int = 1024,
                convention: Optional[Convention] = None) -> str:
    return feilian(message, digest_bits, convention).hex()


# --------------------------------------------------------------------------
#  Streaming API
# --------------------------------------------------------------------------

class FeilianStream:
    """Streaming interface.

    Buffers whole 128-byte blocks and compresses them as they fill, so an
    arbitrarily long message costs O(1) memory.  The final block is held
    back until `digest()` so that its contribution to the counter is known.
    """

    def __init__(self, digest_bits: int = 1024,
                 convention: Optional[Convention] = None):
        if convention is None:
            convention = Convention()
        width = SUPPORTED_WIDTHS.get(digest_bits)
        if width is None:
            raise FeilianError(
                f"unsupported digest width {digest_bits}; "
                f"expected one of {sorted(SUPPORTED_WIDTHS)}")

        self._width = width
        self._conv = convention
        self._state = [list(r) for r in convention.iv()]
        self._buf = bytearray()
        self._bits = 0
        self._blocks_done = 0
        self._finalised = False

    # -- feeding ----------------------------------------------------------

    def update(self, data) -> "FeilianStream":
        if self._finalised:
            raise FeilianError("cannot update after digest()")
        if isinstance(data, str):
            data = data.encode("utf-8")
        self._buf += data
        self._bits += len(data) * 8
        self._drain()
        return self

    def update_bits(self, data, nbits: int) -> "FeilianStream":
        """Feed `nbits` bits taken from the head of `data`.

        Bits past `nbits` in the final byte are cleared before buffering,
        so the digest depends only on the declared bit string.
        """
        if self._finalised:
            raise FeilianError("cannot update after digest()")
        if nbits < 0:
            raise FeilianError("nbits must be non-negative")
        if isinstance(data, str):
            data = data.encode("utf-8")
        need = (nbits + 7) // 8
        if len(data) < need:
            raise FeilianError(f"need {need} bytes for {nbits} bits")
        chunk = bytearray(data[:need])
        if nbits % 8:
            chunk[-1] &= (0xFF << (8 - (nbits % 8))) & 0xFF
        self._buf += bytes(chunk)
        self._bits += nbits
        self._drain()
        return self

    def _drain(self) -> None:
        """Compress every full block except one, which is held back so that
        a later `update()` can still extend this message."""
        while len(self._buf) >= 256:
            self._consume_one()

    def _consume_one(self, is_final: bool = False) -> None:
        """Compress exactly one buffered block.

        A non-final block always contributes the full 1024 bits to the
        cumulative counter, regardless of how many bits have been fed so
        far.  A final full block also contributes 1024 bits, but is marked
        with the final flag.
        """
        block = bytes(self._buf[:128])
        del self._buf[:128]
        total = (self._blocks_done + 1) * 1024
        tweak = _counter_words(total, self._conv.counter_order)
        self._state = _compress(self._state, _load_words(block), is_final,
                                tweak, self._width.version, self._conv)
        self._blocks_done += 1

    # -- output -----------------------------------------------------------

    def digest(self) -> bytes:
        if not self._finalised:
            self._finalise()
        return _serialise(self._state, self._width.hash_rows)

    def hexdigest(self) -> str:
        return self.digest().hex()

    def _finalise(self) -> None:
        """Consume the held-back tail as the final block (or blocks).

        Invariant maintained by `_drain()`: fewer than 256 bytes are
        buffered, i.e. at most one full block plus a partial one.  So the
        tail spans at most two blocks: an optional non-final full block,
        then the final block (which may itself be full).
        """
        self._finalised = True

        absorbed = self._blocks_done * 1024
        tail_bits = self._bits - absorbed
        if tail_bits < 0:
            raise FeilianError("internal bit accounting error")

        # A whole non-final block still sitting in the buffer.
        if tail_bits > 1024:
            self._consume_one()
            tail_bits -= 1024

        if tail_bits == 1024:
            # The message ends exactly on a block boundary.  That single
            # block is the final block; it must be compressed exactly once,
            # as final, and contributes its full 1024 bits.
            self._consume_one(is_final=True)
            return

        # A partial (possibly empty) final block.  Padding never changes
        # the counter, so under the official convention the tail
        # contributes only its real bit length.
        body = bytes(self._buf)
        self._buf = bytearray()
        if len(body) > 127:
            raise FeilianError("internal buffer invariant violated")

        padded = _pad(body, tail_bits)
        if self._conv.final_block_counting == "padded":
            # The Appendix B 512/768 examples charged the padding too.
            final_len = 1024
        else:
            final_len = tail_bits

        total = self._blocks_done * 1024 + final_len
        tweak = _counter_words(total, self._conv.counter_order)
        self._state = _compress(self._state, _load_words(padded), True,
                                tweak, self._width.version, self._conv)

    def copy(self) -> "FeilianStream":
        clone = FeilianStream(self._width.digest_bits, self._conv)
        clone._state = [r[:] for r in self._state]
        clone._buf = bytearray(self._buf)
        clone._bits = self._bits
        clone._blocks_done = self._blocks_done
        return clone

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


# --------------------------------------------------------------------------
#  Self-test
# --------------------------------------------------------------------------

def _self_test() -> int:
    """Cross-check against the submitted C implementation's known outputs."""
    # Values produced by compiling %TEMP%\feilian_sub\FEILIAN and running
    # CryptHash(DIGEST_BIT_LENGTH, msg, bits, digest).
    known = {
        (1024, b"abc", 24): "0507e4b1ef75d025dfa303ea0a8e2c47",
        (1024, b"", 0): "050d49c1ec846087e39b3d33df18b36e",
        (1024, b"a" * 129, 129 * 8): "e3383d3260ea32ed8fe316f8b27cd6be",
    }
    failures = 0
    for (bits, msg, nbits), expected in known.items():
        got = feilian_from_bitstring(msg, nbits, bits).hex()[:32]
        ok = got == expected
        failures += 0 if ok else 1
        print(f"  {'ok ' if ok else 'FAIL'} FEILIAN-{bits}"
              f"({msg[:12]!r}, {nbits}b) -> {got}")

    # spec-chapter-2 convention must reproduce assessment v1.0.2 R2
    r2 = feilian_from_bitstring(b"abc", 24, 1024,
                                Convention.for_spec_chapter2()).hex()[:32]
    ok = r2 == "8b27103d98eabd06b36a8a1d2148d8e6"
    failures += 0 if ok else 1
    print(f"  {'ok ' if ok else 'FAIL'} R2 chapter-2 convention    -> {r2}")

    return failures


if __name__ == "__main__":
    raise SystemExit(_self_test())
