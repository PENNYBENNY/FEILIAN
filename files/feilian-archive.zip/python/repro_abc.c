/*
 * Repro driver for assessment v1.0.2 R2 named experiment.
 * Links the SUBMITTED (pristine) FEILIAN1024 reference implementation
 * and prints FEILIAN-1024("abc") digest bytes.
 */
#include <stdio.h>
#include <string.h>
#include "CryptHash_AlgorithmInstance.h"

static void print_hex(const unsigned char *b, int n)
{
    for (int i = 0; i < n; i++)
        printf("%02x", b[i]);
    printf("\n");
}

static void do_case(const char *label, const unsigned char *msg, unsigned long long bits, int out_bytes)
{
    unsigned char digest[256];
    memset(digest, 0, sizeof(digest));
    int rc = CryptHash(DIGEST_BIT_LENGTH, msg, bits, digest);
    printf("%-28s rc=%d first%d=", label, rc, out_bytes);
    print_hex(digest, out_bytes);
}

int main(void)
{
    printf("DIGEST_BIT_LENGTH = %d\n", DIGEST_BIT_LENGTH);
    printf("ALGORITHM_INSTANCE = %s\n\n", ALGORITHM_INSTANCE);

    /* abc: 3 bytes = 24 bits */
    do_case("FEILIAN-1024(abc)", (const unsigned char *)"abc", 24, 16);

    /* empty message */
    do_case("FEILIAN-1024(empty)", (const unsigned char *)"", 0, 16);

    /* 129 bytes of 'a' */
    {
        unsigned char a[129];
        memset(a, 'a', sizeof(a));
        do_case("FEILIAN-1024(a x129)", a, 129ULL * 8ULL, 16);
    }

    /* Full abc digest, 1024 bits = 128 bytes */
    {
        unsigned char digest[256];
        memset(digest, 0, sizeof(digest));
        int rc = CryptHash(DIGEST_BIT_LENGTH, (const unsigned char *)"abc", 24, digest);
        printf("\nFEILIAN-1024(abc) full 128 bytes (rc=%d):\n", rc);
        for (int i = 0; i < 128; i += 32) {
            printf("  ");
            print_hex(digest + i, 32);
        }
    }
    return 0;
}
