"""
FINAL validation of the independent Python FEILIAN implementation.

Covers everything that can be verified WITHOUT reimplementing the ICCS
DRNG or running the million-iteration loop:

  A. Official KAT_2_12 vectors: 4097 lengths x 3 variants = 12291 digests
     (these are the vectors the assessment report says the C code passes)
  B. Direct cross-check against the compiled submitted C implementation
     for the three messages named in assessment v1.0.2 R2
  C. The R2 "Chapter 2 conventions" digest
  D. Streaming vs one-shot equivalence, including exact block boundaries
  E. Bit-length semantics (trailing bits must not affect the digest)

Anything NOT covered, and why:
  - KAT_2_23 / KAT_2_33: print only a seed plus a first/last-8-byte check
    value, so regenerating the message requires the ICCS DRNG (assessment
    finding R8).  Not attempted.
  - KAT_Loop: the recorded Dst is the result after 1,000,000 chained
    iterations, not a direct hash of the printed message.  Out of scope.
"""

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from feilian import (FeilianStream, feilian, feilian_from_bitstring,
                     Convention)          # noqa: E402

FAILS = []


def line(ok, label, detail=""):
    print(f"  {'ok  ' if ok else 'FAIL'} {label}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(label)


def section(title):
    print()
    print(f"== {title} ==")


# --------------------------------------------------------------------------
section("A. official KAT_2_12 (full official vector set)")
sys.stdout.flush()
r = subprocess.run([sys.executable, str(HERE / "kat_check.py")],
                   capture_output=True, text=True)
for ln in r.stdout.splitlines():
    s = ln.strip()
    if "match" in s or "TOTAL" in s or "mismatches" in s:
        print("  " + s)
kat_total = kat_bad = None
for ln in r.stdout.splitlines():
    s = ln.strip()
    if s.startswith("TOTAL vectors"):
        kat_total = int(s.split(":")[1])
    if s.startswith("mismatches"):
        kat_bad = int(s.split(":")[1])
line(kat_bad == 0 and kat_total == 12291, "KAT_2_12 zero mismatches",
     f"total={kat_total} bad={kat_bad}")

# --------------------------------------------------------------------------
section("B. cross-check against the compiled submitted C code")
exe = HERE / "repro_abc.exe"
if exe.exists():
    out = subprocess.run([str(exe)], capture_output=True, text=True).stdout
    got_c = {}
    for ln in out.splitlines():
        if "first16=" in ln:
            head = ln.split("first16=")[0]          # "FEILIAN-1024(abc) rc=0 "
            label = head.strip().split("  ")[0].strip()
            got_c[label] = ln.split("first16=")[1].strip()
    expect = {
        "FEILIAN-1024(abc)": "0507e4b1ef75d025dfa303ea0a8e2c47",
        "FEILIAN-1024(empty)": "050d49c1ec846087e39b3d33df18b36e",
        "FEILIAN-1024(a x129)": "e3383d3260ea32ed8fe316f8b27cd6be",
    }
    for k, v in expect.items():
        line(got_c.get(k) == v, f"C-code {k}", f"{got_c.get(k)}")

    # our Python implementation must agree with the C code on the same inputs
    line(feilian(b"abc", 1024).hex()[:32] == expect["FEILIAN-1024(abc)"],
         "python == C  on abc")
    line(feilian(b"", 1024).hex()[:32] == expect["FEILIAN-1024(empty)"],
         "python == C  on empty")
    line(feilian(b"a" * 129, 1024).hex()[:32] == expect["FEILIAN-1024(a x129)"],
         "python == C  on a*129")
else:
    line(False, "repro_abc.exe present (build it first)")

# --------------------------------------------------------------------------
section("C. assessment v1.0.2 R2 named experiment")
abc_c = feilian(b"abc", 1024).hex()[:32]
abc_s = feilian(b"abc", 1024, Convention.for_spec_chapter2()).hex()[:32]
line(abc_c == "0507e4b1ef75d025dfa303ea0a8e2c47",
     "supplied-C conventions -> 0507e4b1...", abc_c)
line(abc_s == "8b27103d98eabd06b36a8a1d2148d8e6",
     "Chapter-2 conventions   -> 8b27103d...", abc_s)
line(abc_c != abc_s, "the two conventions really differ")

# --------------------------------------------------------------------------
section("D. streaming == one-shot (incl. exact block boundaries)")
import random                                        # noqa: E402
random.seed(20260929)
bad = 0
for width in (512, 768, 1024):
    for n in list(range(0, 300)) + [511, 512, 513, 1000, 4096]:
        msg = bytes(random.getrandbits(8) for _ in range(n))
        h = FeilianStream(width)
        pos = 0
        while pos < n:
            step = random.choice([1, 2, 5, 17, 64, 128, 200])
            h.update(msg[pos:pos + step])
            pos += step
        if h.digest() != feilian(msg, width):
            bad += 1
            print(f"       mismatch width={width} n={n}")
line(bad == 0, "streaming matches one-shot on 909 cases")

# --------------------------------------------------------------------------
section("E. bit-length semantics")
bad = 0
for nbits in (0, 1, 7, 8, 9, 100, 1023, 1024, 1025, 1032, 2048, 4096):
    nbytes = (nbits + 7) // 8
    msg = bytes(random.getrandbits(8) for _ in range(nbytes))
    a = feilian_from_bitstring(msg, nbits, 1024)
    dirty = bytearray(msg)
    if nbits % 8:
        dirty[-1] |= 0xFF >> (nbits % 8)
    b = feilian_from_bitstring(bytes(dirty), nbits, 1024)
    if a != b:
        bad += 1
        print(f"       trailing bits leaked at nbits={nbits}")
line(bad == 0, "digest depends only on the declared bit string")

# --------------------------------------------------------------------------
print()
if FAILS:
    print(f"FAILURES ({len(FAILS)}): " + ", ".join(FAILS))
    sys.exit(1)
print("ALL CHECKS PASSED")
