"""Consistency tests: streaming == one-shot, and bit-length edge cases."""

import random
from feilian import (FeilianStream, feilian, feilian_from_bitstring,
                     Convention, SUPPORTED_WIDTHS)

random.seed(20260929)
fails = 0


def check(label, a, b):
    global fails
    ok = a == b
    if not ok:
        fails += 1
    print(f"  {'ok  ' if ok else 'FAIL'} {label}")
    if not ok:
        print(f"        a={a.hex()[:48]}")
        print(f"        b={b.hex()[:48]}")


print("== streaming vs one-shot ==")
for bits in (512, 768, 1024):
    for n in (0, 1, 127, 128, 129, 255, 256, 257, 1000):
        msg = bytes(random.getrandbits(8) for _ in range(n))

        h = FeilianStream(bits)
        # feed in awkward chunk sizes
        pos = 0
        while pos < n:
            step = random.choice([1, 3, 7, 31, 64, 100])
            h.update(msg[pos:pos + step])
            pos += step
        check(f"FEILIAN-{bits} n={n}", h.digest(), feilian(msg, bits))

print()
print("== partial-bit inputs ==")
for nbits in (1, 7, 8, 9, 15, 16, 17, 100, 1023, 1024, 1025, 1032):
    nbytes = (nbits + 7) // 8
    msg = bytes(random.getrandbits(8) for _ in range(nbytes))
    d1 = feilian_from_bitstring(msg, nbits, 1024)

    # the same bit string with trailing garbage must give the same digest
    dirty = bytearray(msg)
    if nbits % 8:
        dirty[-1] |= 0xFF >> (nbits % 8)
    d2 = feilian_from_bitstring(bytes(dirty), nbits, 1024)
    check(f"bit-length {nbits} ignores trailing bits", d1, d2)

print()
print("== spec-chapter-2 convention is wired through ==")
c2 = Convention.for_spec_chapter2()
for bits in (512, 768, 1024):
    d_c = feilian(b"abc", bits)
    d_s = feilian(b"abc", bits, c2)
    ok = d_c != d_s
    if not ok:
        fails += 1
    print(f"  {'ok  ' if ok else 'FAIL'} FEILIAN-{bits} C-conv != ch2-conv")

print()
print("== streaming honours the convention too ==")
for bits in (512, 768, 1024):
    h = FeilianStream(bits, c2)
    h.update(b"ab").update(b"c")
    check(f"FEILIAN-{bits} stream ch2", h.digest(), feilian(b"abc", bits, c2))

print()
print(f"FAILURES: {fails}")
raise SystemExit(1 if fails else 0)
