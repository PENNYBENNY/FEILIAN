/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/

#ifndef CRYPTHASH_ALGORITHM_INSTANCE_H
#define CRYPTHASH_ALGORITHM_INSTANCE_H

#define OUTPUT_BLANK_TEST_VECTORS 0
#define ALGORITHM_INSTANCE "FEILIAN_SIMD1024"
#define DIGEST_BIT_LENGTH 1024

#ifdef __cplusplus
extern "C"
{
#endif

    /// @brief Input message to get message digests of specified lengths
    /// @param[in] digest_len_bits The total BITS of digest
    /// @param[in] msg The base address of message
    /// @param[in] msg_len_bits The total BITS of message. The message is a bit
    ///        string: when the length is not a multiple of 8, the message ends
    ///        inside the last byte and the remaining low-order bits of that
    ///        byte lie outside the message and shall not affect the digest.
    /// @param[out] digest The base address of digest
    /// @return 0 for success. A non-zero value means the arguments were invalid
    ///         or the padded message could not be built; no digest is produced
    ///         in that case and the caller must not use the output buffer.
    int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest);

#ifdef __cplusplus
}
#endif
#endif
